#include "DefaultShader.h"

namespace Blue
{
	DefaultShader::DefaultShader()
		: Shader(TEXT("Default"))
	{
	}
}