#pragma once

#include "Shader/NormalSpecularMappingShader.h"

namespace Blue
{
	class JamesShoesShader : public NormalSpecularMappingShader
	{
	public:
		JamesShoesShader();
		~JamesShoesShader() = default;
	};
}