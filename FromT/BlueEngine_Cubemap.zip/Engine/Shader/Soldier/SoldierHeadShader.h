#pragma once

#include "Shader/NormalSpecularMappingShader.h"

namespace Blue
{
	class SoldierHeadShader : public NormalSpecularMappingShader
	{
	public:
		SoldierHeadShader();
		~SoldierHeadShader() = default;
	};
}