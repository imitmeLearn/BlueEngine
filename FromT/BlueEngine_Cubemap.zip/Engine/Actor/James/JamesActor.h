#pragma once

#include "Actor/Actor.h"

namespace Blue
{
	class JamesActor : public Actor
	{
	public:
		JamesActor();
		~JamesActor() = default;
	};
}