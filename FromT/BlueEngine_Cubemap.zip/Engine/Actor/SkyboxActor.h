#pragma once

#include "Actor.h"

namespace Blue
{
	class SkyboxActor : public Actor
	{
	public:
		SkyboxActor();
		~SkyboxActor() = default;
	};
}