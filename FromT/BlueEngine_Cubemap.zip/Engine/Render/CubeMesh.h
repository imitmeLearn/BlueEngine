#pragma once

#include "Mesh.h"

namespace Blue
{
	class CubeMesh : public Mesh
	{
	public:
		CubeMesh();
		~CubeMesh() = default;
	};
}