#pragma once

#include "Render/Mesh.h"

namespace Blue
{
	class JamesMesh : public Mesh
	{
	public:
		JamesMesh();
		~JamesMesh() = default;
	};
}