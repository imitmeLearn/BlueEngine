#pragma once

#include "Render/Mesh.h"

namespace Blue
{
	class SoldierMesh : public Mesh
	{
	public:
		SoldierMesh();
		~SoldierMesh() = default;
	};
}