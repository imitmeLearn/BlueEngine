#pragma once

#include "NormalMappingShader.h"

namespace Blue
{
	class SoldierHeadShader : public NormalMappingShader
	{
	public:
		SoldierHeadShader();
		~SoldierHeadShader() = default;
	};
}