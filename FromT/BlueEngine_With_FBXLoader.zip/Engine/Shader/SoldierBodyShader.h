#pragma once

#include "NormalMappingShader.h"

namespace Blue
{
	class SoldierBodyShader : public NormalMappingShader
	{
	public:
		SoldierBodyShader();
		~SoldierBodyShader() = default;
	};
}