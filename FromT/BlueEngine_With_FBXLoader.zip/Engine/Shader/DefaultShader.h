#pragma once

#include "Shader.h"

namespace Blue
{
	class DefaultShader : public Shader
	{
	public:
		DefaultShader();
	};
}