#pragma once

#include "Actor.h"

namespace Blue
{
	class SoldierActor : public Actor
	{
	public:
		SoldierActor();
		~SoldierActor() = default;
	};
}