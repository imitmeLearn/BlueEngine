#include "Shader.h"
#include <d3dcompiler.h>
#include "../Core/Engine.h"

namespace Blue
{
	Shader::Shader(const std::wstring& name)
	{
		wchar_t path[256] = {};
		swprintf(path, 256, TEXT("HLSLShader/%sVertexShader.hlsl"), name.c_str());

		// ���̴� ������.
		HRESULT result = D3DCompileFromFile(
			path,
			nullptr,
			nullptr,
			"main",
			"vs_5_0",
			0, 0,
			&vertexShaderBuffer, nullptr
		);

		if (FAILED(result))
		{
			MessageBoxA(
				nullptr,
				"Failed to compile vertex shader",
				"Error",
				MB_OK
			);

			__debugbreak();
		}

		ID3D11Device& device = Engine::Get().Device();

		// ���̴� ����.
		result = device.CreateVertexShader(
			vertexShaderBuffer->GetBufferPointer(),
			vertexShaderBuffer->GetBufferSize(),
			nullptr,
			&vertexShader
		);

		if (FAILED(result))
		{
			MessageBoxA(
				nullptr,
				"Failed to create vertex shader",
				"Error",
				MB_OK
			);

			__debugbreak();
		}

		// �Է� ���̾ƿ�.
		// ���� ���̴��� ������ ���� �����Ͱ� ��� ������� �˷���.
		D3D11_INPUT_ELEMENT_DESC inputDesc[] =
		{
			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D11_INPUT_PER_VERTEX_DATA, 0 }
		};

		result = device.CreateInputLayout(
			inputDesc,
			1,
			vertexShaderBuffer->GetBufferPointer(),
			vertexShaderBuffer->GetBufferSize(),
			&inputlayout
		);

		if (FAILED(result))
		{
			MessageBoxA(
				nullptr,
				"Failed to create input layout",
				"Error",
				MB_OK
			);

			__debugbreak();
		}

		// �ȼ� ���̴� ������/����.
		// �� ���ҽ� ���ε�.
		swprintf(path, 256, TEXT("HLSLShader/%sPixelShader.hlsl"), name.c_str());
		result = D3DCompileFromFile(
			path, 
			nullptr, 
			nullptr, 
			"main", 
			"ps_5_0", 
			0u, 
			0u, 
			&pixelShaderBuffer, 
			nullptr
		);

		if (FAILED(result))
		{
			MessageBoxA(
				nullptr,
				"Failed to compile pixel shader",
				"Error",
				MB_OK
			);

			__debugbreak();
		}

		result = device.CreatePixelShader(
			pixelShaderBuffer->GetBufferPointer(),
			pixelShaderBuffer->GetBufferSize(),
			nullptr,
			&pixelShader
		);

		if (FAILED(result))
		{
			MessageBoxA(
				nullptr,
				"Failed to compile pixel shader",
				"Error",
				MB_OK
			);

			__debugbreak();
		}
	}

	Shader::~Shader()
	{
		if (inputlayout)
		{
			inputlayout->Release();
		}

		if (vertexShader)
		{
			vertexShader->Release();
		}

		if (vertexShaderBuffer)
		{
			vertexShaderBuffer->Release();
		}

		if (pixelShader)
		{
			pixelShader->Release();
		}
		
		if (pixelShaderBuffer)
		{
			pixelShaderBuffer->Release();
		}
	}

	void Shader::Bind()
	{
		static ID3D11DeviceContext& context = Engine::Get().Context();
		context.IASetInputLayout(inputlayout);
		context.VSSetShader(vertexShader, nullptr, 0);
		context.PSSetShader(pixelShader, nullptr, 0);
	}
}