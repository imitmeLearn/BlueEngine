#pragma once

#include <d3d11.h>
#include <string>
#include <memory>

namespace Blue
{
	class Shader
	{
	public:
		Shader(const std::wstring& name);
		virtual ~Shader();

		virtual void Bind();

	protected:
		std::wstring name;
		
		ID3D11InputLayout* inputlayout = nullptr;
		
		ID3D11VertexShader* vertexShader = nullptr;
		ID3DBlob* vertexShaderBuffer = nullptr;

		ID3D11PixelShader* pixelShader = nullptr;
		ID3DBlob* pixelShaderBuffer = nullptr;
	};
}