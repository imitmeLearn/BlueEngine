#include "TriangleMesh.h"
#include "Vertex.h"

namespace Blue
{
	TriangleMesh::TriangleMesh()
	{
		std::vector<Vertex> vertices =
		{
			Vertex(0.0f, 0.5f, 0.5f),
			Vertex(0.5f, -0.5f, 0.5f),
			Vertex(-0.5f, -0.5f, 0.5f),
		};

		std::vector<uint32> indices = { 0, 1, 2 };

		std::shared_ptr<MeshData> meshData = std::make_shared<MeshData>(vertices, indices);
		meshes.emplace_back(meshData);

		std::shared_ptr<Shader> shader = std::make_shared<Shader>(TEXT("Default"));
		shaders.emplace_back(shader);
	}
}