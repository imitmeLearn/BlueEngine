#pragma once

#include "Mesh.h"

namespace Blue
{
	class TriangleMesh : public Mesh
	{
	public:
		TriangleMesh();
	};
}