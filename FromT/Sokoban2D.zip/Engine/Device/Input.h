#pragma once

namespace Ronnie
{
	class KeyState
	{
	public:
		bool state = false;
		bool hasConsumed = false;

		operator bool() { return state; }
		bool operator =(bool newState)
		{
			state = newState;
			return state;
		}
	};

	class Input
	{
	public:
		static void SetKeyState(int key, bool state);
		static bool GetKeyDown(int key);
		static bool GetKeyUp(int key);
		static bool GetKey(int key);

		static int KeyCount() { return 255; }

	private:
		static KeyState currentKeyState[255];
		static KeyState thisFrameKeyDown[255];
		static KeyState thisFrameKeyUp[255];
	};
}