#pragma once

#include <PreCompiledHeader.h>

namespace Ronnie
{
	class EngineTime
	{
		friend class Engine;

	public:
		EngineTime() = default;
		~EngineTime() = default;

		void Start();
		void Update();
		void UpdateFrameTime();
		float FrameTime();

	private:
		int64 frequency = 0;
		int64 currentTime = 0;
		int64 previousTime = 0;
		float frameTime = 0.0f;
		int32 framesPerSecond = 0;
	};
}