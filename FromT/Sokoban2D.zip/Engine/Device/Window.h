#pragma once

#include "PreCompiledHeader.h"

namespace Ronnie
{
	class Window
	{
	public:
		Window(uint32 width, uint32 height, const wchar_t* title, class Engine* engine);
		~Window();

		void Run(class Engine* engine);
		void OnResize(uint32 width, uint32 height);
		void SetActive(bool active);

		std::wstring Title() const { return title; }
		HWND Handle() const { return window; }

	private:
		static LRESULT CALLBACK MessageProcedure(HWND handle, UINT message, WPARAM wparam, LPARAM lparam);

	private:
		HWND window = nullptr;
		const wchar_t* title;
		class Engine* ownerEngine = nullptr;
	};
}