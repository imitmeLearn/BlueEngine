#include <PreCompiledHeader.h>
#include "Input.h"

namespace Ronnie
{
	KeyState Input::currentKeyState[255];
	KeyState Input::thisFrameKeyDown[255];
	KeyState Input::thisFrameKeyUp[255];

	void Input::SetKeyState(int key, bool state)
	{
		if (state == true && Input::currentKeyState[key] == false)
		{
			Input::thisFrameKeyDown[key] = true;
			Input::thisFrameKeyDown[key].hasConsumed = false;
		}

		if (state == false && Input::currentKeyState[key] == true)
		{
			Input::thisFrameKeyUp[key] = true;
			Input::thisFrameKeyUp[key].hasConsumed = false;
		}

		Input::currentKeyState[key] = state;
	}

	bool Input::GetKeyDown(int key)
	{
		bool keyDown = (thisFrameKeyDown[key].state == true && thisFrameKeyDown[key].hasConsumed == false);
		thisFrameKeyDown[key].state = false;
		thisFrameKeyDown[key].hasConsumed = true;

		return keyDown;
	}

	bool Input::GetKeyUp(int key)
	{
		bool keyUp = (thisFrameKeyUp[key].state == true && thisFrameKeyUp[key].hasConsumed == false);
		thisFrameKeyUp[key].state = false;
		thisFrameKeyUp[key].hasConsumed = true;

		return keyUp;
	}

	bool Input::GetKey(int key)
	{
		return GetAsyncKeyState(key);
	}
}