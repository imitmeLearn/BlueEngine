#include <PreCompiledHeader.h>
#include "EngineTime.h"

namespace Ronnie
{
	void EngineTime::Start()
	{
		frequency = QueryFrequency();
		currentTime = QueryCounter();
	}

	void EngineTime::Update()
	{
		currentTime = QueryCounter();
	}

	void EngineTime::UpdateFrameTime()
	{
		//frameTime = static_cast<float>(currentTime - previousTime) / static_cast<float>(frequency);
		previousTime = currentTime;
	}

	float EngineTime::FrameTime()
	{
		frameTime = static_cast<float>(currentTime - previousTime) / static_cast<float>(frequency);
		return frameTime;
	}
}