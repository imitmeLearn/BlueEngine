#include <PreCompiledHeader.h>
#include "Window.h"
#include <Engine/Engine.h>

namespace Ronnie
{
	Window::Window(uint32 width, uint32 height, const wchar_t* title, Engine* engine)
		: title(title), ownerEngine(engine)
	{
		ThrowIfFailed(CoInitialize(nullptr), TEXT("Failed to CoInitialize"));

		WNDCLASSEX wndClass = {};
		wndClass.cbSize = sizeof(WNDCLASSEX);
		wndClass.cbWndExtra = 4;
		wndClass.hInstance = GetModuleHandle(nullptr);
		wndClass.lpszClassName = TEXT("Render Window Class");
		wndClass.hCursor = LoadCursor(wndClass.hInstance, IDI_APPLICATION);
		wndClass.hIcon = LoadIcon(wndClass.hInstance, IDC_ARROW);
		wndClass.style = CS_VREDRAW | CS_HREDRAW;
		wndClass.lpfnWndProc = MessageProcedure;

		if (!RegisterClassEx(&wndClass))
		{
			ThrowWithMessage(TEXT("Failed to register window class."));
		}

		RECT rect = { 0, 0, static_cast<long>(width), static_cast<long>(height) };
		AdjustWindowRect(&rect, WS_OVERLAPPEDWINDOW, FALSE);

		uint32 windowWidth = rect.right - rect.left;
		uint32 windowHeight = rect.bottom - rect.top;
		uint32 xPosition = (GetSystemMetrics(SM_CXSCREEN) - windowWidth) / 2;
		uint32 yPosition = (GetSystemMetrics(SM_CYSCREEN) - windowHeight) / 2;

		window = CreateWindow(
			wndClass.lpszClassName,
			title,
			WS_OVERLAPPEDWINDOW,
			xPosition, yPosition,
			windowWidth, windowHeight,
			nullptr,
			nullptr,
			wndClass.hInstance,
			nullptr
		);

		if (window == nullptr)
		{
			ThrowWithMessage(TEXT("Failed to create window"));
		}
		
		SetWindowLongPtr(window, GWLP_USERDATA, (LONG_PTR)this);

		ShowWindow(window, SW_SHOW);
		UpdateWindow(window);
	}

	Window::~Window()
	{
		CoUninitialize();
	}

	void Window::Run(Engine* engine)
	{
		MSG message = {};
		while (message.message != WM_QUIT)
		{
			// ������ �޽��� ó��.
			if (PeekMessage(&message, nullptr, 0u, 0u, PM_REMOVE))
			{
				TranslateMessage(&message);
				DispatchMessage(&message);
			}

			// ������ �޽����� ���� �� ���� �޽��� ó��.
			else
			{
				if (engine != nullptr)
				{
					engine->Update();
				}
			}
		}
	}

	void Window::OnResize(uint32 width, uint32 height)
	{
		if (ownerEngine != nullptr)
		{
			ownerEngine->OnResize(width, height);
		}
	}

	void Window::SetActive(bool active)
	{
		if (ownerEngine != nullptr)
		{
			ownerEngine->SetActive(active);
		}
	}

	LRESULT Window::MessageProcedure(HWND handle, UINT message, WPARAM wparam, LPARAM lparam)
	{
		switch (message)
		{
		case WM_SIZE:
		{
			Window* window = reinterpret_cast<Window*>(GetWindowLongPtr(handle, GWLP_USERDATA));
			if (window != nullptr)
			{
				int reason = static_cast<int>(wparam);
				if (reason == SIZE_MINIMIZED)
				{
					window->SetActive(false);
					return 0;
				}

				if (reason == SIZE_RESTORED)
				{
					window->SetActive(true);
				}

				window->OnResize(LOWORD(lparam), HIWORD(lparam));
				return 0;
			}
			else
			{
				OutputDebugString(L"WM_SIZE window is nullptr\n");
			}

		} break;

		case WM_DESTROY:
		{
			PostQuitMessage(0);
			return 0;
		};

		case WM_ACTIVATEAPP:
		{
			//std::cout << "WM_ACTIVATEAPP: " << static_cast<bool>(lparam) << "\n";
			//return 0;
		} break;

		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(handle, &ps);

			// All painting occurs here, between BeginPaint and EndPaint.
			FillRect(hdc, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW));
			EndPaint(handle, &ps);

			return 0;
		};

		default:
			break;
		}

		return DefWindowProc(handle, message, wparam, lparam);
	}
}