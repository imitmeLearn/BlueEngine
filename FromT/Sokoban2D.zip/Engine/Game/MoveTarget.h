#pragma once

#include "Entity.h"

namespace Ronnie
{
	class MoveTarget : public Entity
	{
	public:
		MoveTarget(const char* textureName = "environment_02.png");
	};
}