#include <PreCompiledHeader.h>
#include "Entity.h"
#include <Math/Transform.h>
#include <Sprite/Sprite.h>
#include <Engine/Engine.h>
#include <Render/Texture.h>

namespace Ronnie
{
	Entity::Entity(const char* textureName)
	{
		transform = new Transform();
		sprite = new Sprite(textureName);

		XMFLOAT3 cratePosition = transform->Position();
		cratePosition.z = 0.2f;
		transform->SetPosition(cratePosition);
	}

	Entity::Entity(Texture* texture)
	{
		transform = new Transform();
		sprite = new Sprite(texture);

		XMFLOAT3 cratePosition = transform->Position();
		cratePosition.z = 0.2f;
		transform->SetPosition(cratePosition);
	}

	Entity::~Entity()
	{
		SafeDelete(transform);
		SafeDelete(name);
	}

	void Entity::Update(float deltaTime)
	{
		transform->Update();
		sprite->Update(deltaTime);
	}

	void Entity::Bind()
	{
		transform->Bind();
		sprite->Bind();
	}

	void Entity::Draw()
	{
		Bind();
		g_Engine->Context()->DrawIndexed(sprite->IndexCount(), 0u, 0u);
	}

	void Entity::SetName(const char* name)
	{
		int length = static_cast<int>(strlen(name) + 1);
		this->name = new char[length];
		memcpy(this->name, name, length);
		this->name[length - 1] = '\0';
	}
}