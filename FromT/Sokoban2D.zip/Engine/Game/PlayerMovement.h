#pragma once

namespace Ronnie
{
	class PlayerMovement
	{
	public:
		PlayerMovement(class Player* player);
		~PlayerMovement();

		void Update(float deltaTime);

	private:
		float moveSpeed = 3.0f;
		class Player* player = nullptr;
	};
}