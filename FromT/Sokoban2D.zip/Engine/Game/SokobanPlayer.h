#pragma once

#include "Player.h"

namespace Ronnie
{
	class SokokbanPlayer : public Player
	{
	public:
		SokokbanPlayer();
		~SokokbanPlayer();
	};
}