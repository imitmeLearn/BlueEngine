#include <PreCompiledHeader.h>
#include "PlayerMovement.h"
#include <Math/Transform.h>
#include <DirectXMath.h>
#include "Player.h"
#include <Engine/Engine.h>
#include <Device/Input.h>
#include <Command/PlayerMovementCommand.h>
#include <Command/CommandManager.h>

namespace Ronnie
{
	using namespace DirectX;

	PlayerMovement::PlayerMovement(Player* player)
		: player(player)
	{
	}

	PlayerMovement::~PlayerMovement()
	{
	}
	
	void PlayerMovement::Update(float deltaTime)
	{
		bool hasMoved = false;
		XMFLOAT3 checkPosition = player->GetTransform()->Position();
		Texture* targetTexture = nullptr;

		if (Input::GetKeyDown(VK_RIGHT) || Input::GetKeyDown('D'))
		{
			hasMoved = true;
			checkPosition.x += 1.0f;
			targetTexture = player->right;
		}

		if (Input::GetKeyDown(VK_LEFT) || Input::GetKeyDown('A'))
		{
			hasMoved = true;
			checkPosition.x += -1.0f;
			targetTexture = player->left;
		}
		
		if (Input::GetKeyDown(VK_UP) || Input::GetKeyDown('W'))
		{
			hasMoved = true;
			checkPosition.y += 1.0f;
			targetTexture = player->up;
		}

		if (Input::GetKeyDown(VK_DOWN) || Input::GetKeyDown('S'))
		{
			hasMoved = true;
			checkPosition.y += -1.0f;
			targetTexture = player->down;
		}

		// �̵� ������ �÷��̾� �̵� Ƚ�� ����.
		if (hasMoved == true)
		{
			PlayerMovementCommandState* newCommandState = new PlayerMovementCommandState();
			newCommandState->player = player;
			newCommandState->playerCurrentPosition = player->GetTransform()->Position();
			newCommandState->playerNewPosition = checkPosition;
			newCommandState->playerCurrentTexture = player->currentTexture;
			newCommandState->playerNewTexture = targetTexture;

			//PlayerMovementCommand* newCommand = new PlayerMovementCommand()
			if (player->CanMove(checkPosition, newCommandState) == true)
			{
				player->GetTransform()->SetPosition(checkPosition);
				player->currentTexture = targetTexture;
				
				g_Engine->AddCommand(new PlayerMovementCommand(newCommandState), false);
				player->AddPlayerMovementCount();
			}
		}
	}
}