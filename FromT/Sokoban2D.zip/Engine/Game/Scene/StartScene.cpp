#include <PreCompiledHeader.h>
#include "StartScene.h"
#include <Render/Text.h>
#include <Engine/Engine.h>
#include <Device/Input.h>
#include <Resource/Sound.h>
#include <Render/Texture.h>
#include <Game/Entity.h>
#include <Math/Transform.h>

namespace Ronnie
{
	StartScene::StartScene(Engine* engine)
		: Scene(engine)
	{
		// ���� ����.
		// rgba(26,37,38,255)
		backgroundColor[0] = 0.1f;
		backgroundColor[1] = 0.145f;
		backgroundColor[2] = 0.15f;
		backgroundColor[3] = 1.0f;

		// �ؽ�ó ����.
		stageStartTexture = new Texture("../Assets/Textures/StartStageBackground.png");

		// ��� ��������Ʈ ����.
		backgroundObject = new Entity(stageStartTexture);
		backgroundObject->GetTransform()->SetScale(15.0f, 10.0f, 1.0f);

		// ���� Ÿ��Ʋ �ؽ�Ʈ ����.
		gameTitleText = new Text();
		gameTitleText->SetText(TEXT("Sokoban Game"));
		gameTitleText->SetFontSize(40.0f);

		// �޴� �ؽ�Ʈ ����.
		Text* testText1 = new Text();
		testText1->SetText(TEXT("Game Start"));

		Text* testText2 = new Text();
		testText2->SetText(TEXT("Quit Game"));
		menuTexts.emplace_back(testText1);
		menuTexts.emplace_back(testText2);

		// ��� ���� ���� ���� �� ���.
		backgroundMusic = new Sound(TEXT("../Assets/Sounds/BGM.wav"));
		backgroundMusic->Play();
	}

	StartScene::~StartScene()
	{
		SafeDelete(stageStartTexture);
		SafeDelete(backgroundObject);
		SafeDelete(gameTitleText);
		
		//backgroundMusic->Stop();
		SafeDelete(backgroundMusic);

		for (Text* text : menuTexts)
		{
			SafeDelete(text);
		}
	}

	void StartScene::Update(float deltaTime)
	{
		// ����ó�� -> ���� �ʱ�ȭ �ȵ� ����.
		if (deltaTime > 1.0f || deltaTime < 0.0f)
		{
			return;
		}

		static float selectedFontSize = 30.0f;
		static D2D1::ColorF selectedFontColor = D2D1::ColorF::Yellow;
		static float unselectedFontSize = 25.0f;
		static D2D1::ColorF unselectedFontColor = D2D1::ColorF::White;

		if (Input::GetKeyDown(VK_UP))
		{
			currentSelectedText = (currentSelectedText - 1) % (int)menuTexts.size();
			currentSelectedText = currentSelectedText < 0 ? currentSelectedText + (int)menuTexts.size() : currentSelectedText;
		}

		if (Input::GetKeyDown(VK_DOWN))
		{
			currentSelectedText = (currentSelectedText + 1) % (int)menuTexts.size();
		}

		if (Input::GetKeyDown(VK_RETURN))
		{
			// Game Start�� ���õ� ���.
			if (currentSelectedText == 0)
			{
				g_Engine->ChangeScene(1);
			}
			
			// Quit Game�� ���õ� ���.
			else if (currentSelectedText == 1)
			{
				g_Engine->QuitGame();
			}
		}

		// �޴� �ؽ�Ʈ ��Ʈũ��/��Ʈ ���� ����.
		for (int ix = 0; ix < (int)menuTexts.size(); ++ix)
		{
			if (ix == currentSelectedText)
			{
				menuTexts[ix]->SetFontSize(selectedFontSize);
				menuTexts[ix]->SetFontColor(selectedFontColor);
				continue;
			}

			menuTexts[ix]->SetFontSize(unselectedFontSize);
			menuTexts[ix]->SetFontColor(unselectedFontColor);
		}

		// �������� ������Ʈ.
		backgroundObject->Update(deltaTime);
	}

	void StartScene::Draw()
	{
		backgroundObject->Draw();

		// ���� Ÿ��Ʋ �ؽ�Ʈ ��ο�.
		gameTitleText->Draw(D2D1::Point2F(static_cast<float>(g_Engine->Width() / 2.0f) - 150.0f, static_cast<float>(g_Engine->Height()) / 2.0f - 200.0f));

		// �޴� �ؽ�Ʈ ��ο�.
		for (int ix = 0; ix < (int)menuTexts.size(); ++ix)
		{
			Text* text = menuTexts[ix];
			text->Draw(D2D1::Point2F(static_cast<float>(g_Engine->Width() / 2.0f) - (text->Width() / 2.5f), static_cast<float>(g_Engine->Height()) / 2.5f + ix * 50.0f));
		}
	}
}