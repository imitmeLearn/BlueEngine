#include "PreCompiledHeader.h"
#include "Scene.h"

namespace Ronnie
{
	Scene::Scene(Engine* engine)
		: engine(engine)
	{
	}
	
	Scene::~Scene()
	{
	}
}