#pragma once

namespace Ronnie
{
	class Scene
	{
	public:
		Scene(class Engine* engine);
		virtual ~Scene();

		virtual void Update(float deltaTime) = 0;
		virtual void Draw() = 0;

	public:
		float backgroundColor[4];

	protected:
		class Engine* engine = nullptr;
	};
}