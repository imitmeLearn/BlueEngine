#include <PreCompiledHeader.h>
#include "MenuScene.h"
#include <Engine/Engine.h>
#include <Render/Text.h>
#include <Engine/Engine.h>
#include <Device/Input.h>

namespace Ronnie
{
	MenuScene::MenuScene(Engine* engine)
		: Scene(engine)
	{
		// �޴� ���� ���� ����.
		backgroundColor[0] = 0.0f;
		backgroundColor[1] = 0.3f;
		backgroundColor[2] = 0.4f;
		backgroundColor[3] = 1.0f;

		// ���� Ÿ��Ʋ �ؽ�Ʈ ����.
		gameTitleText = new Text(TEXT("Jetbrains Mono"), 40.0f, D2D1::ColorF::White, 300.0f);
		
		gameTitleText->SetFontSize(40.0f);
		gameTitleText->SetText(TEXT("Sokoban Game Menu"));
		gameTitleText->SetWidth(408.0f);

		std::cout << gameTitleText->LayoutWidth() << " : " << gameTitleText->Width() << "\n";

		// �޴� �ؽ�Ʈ ����.
		Text* testText1 = new Text();
		testText1->SetText(TEXT("Resume Game"));

		Text* testText2 = new Text();
		testText2->SetText(TEXT("Quit Game"));

		menuTexts.emplace_back(testText1);
		menuTexts.emplace_back(testText2);
	}

	MenuScene::~MenuScene()
	{
		SafeDelete(gameTitleText);
		for (Text* text : menuTexts)
		{
			SafeDelete(text);
		}

		menuTexts.clear();
	}
	
	void MenuScene::Update(float deltaTime)
	{
		// ����ó�� -> ���� �ʱ�ȭ �ȵ� ����.
		if (deltaTime > 1.0f || deltaTime < 0.0f)
		{
			return;
		}

		static float selectedFontSize = 30.0f;
		static D2D1::ColorF selectedFontColor = D2D1::ColorF::Yellow;
		static float unselectedFontSize = 25.0f;
		static D2D1::ColorF unselectedFontColor = D2D1::ColorF::White;

		if (Input::GetKeyDown(VK_UP))
		{
			currentSelectedText = (currentSelectedText - 1) % (int)menuTexts.size();
			currentSelectedText = currentSelectedText < 0 ? currentSelectedText + (int)menuTexts.size() : currentSelectedText;
		}

		if (Input::GetKeyDown(VK_DOWN))
		{
			currentSelectedText = (currentSelectedText + 1) % (int)menuTexts.size();
		}

		if (Input::GetKeyDown(VK_RETURN))
		{
			// Game Start�� ���õ� ���.
			if (currentSelectedText == 0)
			{
				//RHI::ChangeScene(1);
				g_Engine->ResumeGame();
			}

			// Quit Game�� ���õ� ���.
			else if (currentSelectedText == 1)
			{
				g_Engine->QuitGame();
			}
		}

		// �޴� �ؽ�Ʈ ��Ʈũ��/��Ʈ ���� ����.
		for (int ix = 0; ix < (int)menuTexts.size(); ++ix)
		{
			if (ix == currentSelectedText)
			{
				menuTexts[ix]->SetFontSize(selectedFontSize);
				menuTexts[ix]->SetFontColor(selectedFontColor);
				continue;
			}

			menuTexts[ix]->SetFontSize(unselectedFontSize);
			menuTexts[ix]->SetFontColor(unselectedFontColor);
		}
	}
	
	void MenuScene::Draw()
	{
		// ���� Ÿ��Ʋ �ؽ�Ʈ ��ο�.
		float xPosition = (static_cast<float>(g_Engine->Width()) / 2.0f) - (gameTitleText->Width() / 2.0f);
		float yPosition = static_cast<float>(g_Engine->Height()) / 2.0f - (200.0f);
		gameTitleText->Draw(D2D1::Point2F(xPosition, yPosition));

		// �޴� �ؽ�Ʈ ��ο�.
		float yOffset = 50.0f;
		for (int ix = 0; ix < (int)menuTexts.size(); ++ix)
		{
			Text* text = menuTexts[ix];
			float textXPosition = static_cast<float>(g_Engine->Width() / 2.0f) - (text->Width() / 1.5f);
			float textYPosition = yPosition + 50.0f + (ix + 1) * yOffset;
			text->Draw(D2D1::Point2F(xPosition, textYPosition));
		}
	}
}