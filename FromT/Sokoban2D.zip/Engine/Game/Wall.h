#pragma once

#include "Entity.h"

namespace Ronnie
{
	class Wall : public Entity
	{
	public:
		Wall(const char* textureName = "block_06.png");
	};
}