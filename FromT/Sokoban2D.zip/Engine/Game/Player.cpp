#include <PreCompiledHeader.h>
#include "Player.h"
#include "Sprite/SpriteAnimation.h"
#include <Engine/Engine.h>
#include <Math/Transform.h>
#include "PlayerMovement.h"
#include "Scene/GameScene.h"
#include <Resource/TextureManager.h>
#include <Command/PlayerMovementCommand.h>

namespace Ronnie
{
	Player::Player()
		: currentAnimation(nullptr)
	{
		transform = new Transform();
		movement = new PlayerMovement(this);

		right = TextureManager::LoadTexture("player_09.png");
		left = TextureManager::LoadTexture("player_12.png");
		up = TextureManager::LoadTexture("player_24.png");
		down = TextureManager::LoadTexture("player_21.png");

		currentTexture = right;

		playerSprite = new Sprite(currentTexture);
	}

	Player::Player(SpriteAnimation** animationList, int count)
		: currentAnimation(nullptr)
	{
		transform = new Transform();
		movement = new PlayerMovement(this);

		// �ִϸ��̼� ��Ͽ� �ִϸ��̼� �߰�.
		//for (int ix = 0; ix < count; ++ix)
		//{
		//	animations.insert({ animationList[ix]->name, animationList[ix] });
		//}

		//transform->SetScale(1.0f, 1.0f, 1.0f);
		//currentAnimation = animationList[0];
	}

	Player::~Player()
	{
		for (const std::pair<std::string_view, SpriteAnimation*>& animation : animations)
		{
			SafeDelete(animation.second);
		}

		SafeDelete(transform);
		SafeDelete(movement);
		SafeDelete(playerSprite);
	}

	void Player::Update(float deltaTime)
	{
		transform->Update();
		playerSprite->SetTexture(currentTexture);

		//if (currentAnimation != nullptr)
		//{
		//	currentAnimation->Update(deltaTime);
		//}

		if (movement != nullptr)
		{
			movement->Update(deltaTime);
		}
	}

	void Player::Bind()
	{
		transform->Bind();
		playerSprite->Bind();

		//if (currentAnimation != nullptr)
		//{
		//	currentAnimation->Bind();
		//}
	}

	void Player::Draw()
	{
		Bind();
		g_Engine->Context()->DrawIndexed(playerSprite->IndexCount(), 0u, 0u);

		//if (currentAnimation != nullptr)
		//{
		//	RHI::GetContext()->DrawIndexed(currentAnimation->IndexCount(), 0u, 0u);
		//}
	}

	void Player::SetScene(GameScene* gameManager)
	{
		this->scene = gameManager;
	}

	bool Player::CanMove(const XMFLOAT3& checkPosition, PlayerMovementCommandState* commandState)
	{
		return (scene->IsStageClear() == false) && scene->CanMove(transform->Position(), checkPosition, commandState);
	}

	void Player::AddAnimation(SpriteAnimation* animation)
	{
		// �̹� �߰��� �ִϸ��̼��� ��쿡�� �Լ� ����.
		auto search = animations.find(animation->name);
		if (search != animations.end())
		{
			return;
		}

		// �ִϸ��̼��� ��Ͽ� �߰�.
		animations.insert({ animation->name, animation });
	}

	void Player::ChangeAnimation(const char* name)
	{
		// �����Ϸ��� �ִϸ��̼��� �̹� ���õ� ������ �Լ� ����.
		if (currentAnimation != nullptr && strcmp(currentAnimation->name, name) == 0)
		{
			return;
		}

		// ��Ͽ��� �ִϸ��̼��� ã�� �Ŀ� �ִϸ��̼� ��ȯ.
		auto search = animations.find(name);
		if (search != animations.end())
		{
			currentAnimation = search->second;
		}
	}

	void Player::SetTexture(Texture* texture)
	{
		currentTexture = texture;
	}

	void Player::SetPosition(const XMFLOAT3& position)
	{
		transform->SetPosition(position);
	}

	void Player::SetPosition(float x, float y, float z)
	{
		transform->SetPosition(x, y, z);
	}

	void Player::Translate(const XMFLOAT3& amount)
	{
		XMFLOAT3 position = transform->Position();
		XMFLOAT3 newPosition = XMFLOAT3(position.x + amount.x, position.y + amount.y, position.z + amount.z);
		transform->SetPosition(newPosition);
	}

	void Player::Translate(float x, float y, float z)
	{
		XMFLOAT3 position = transform->Position();
		XMFLOAT3 newPosition = XMFLOAT3(position.x + x, position.y + y, position.z + z);
		transform->SetPosition(newPosition);
	}

	void Player::AddPlayerMovementCount()
	{
		scene->AddPlayerMovementCount();
	}
}