#pragma once

#include <DirectXMath.h>
#include <unordered_map>
#include <string_view>

namespace Ronnie
{
	using namespace DirectX;

	class Texture;
	class Player
	{
		friend class PlayerMovement;

	public:
		Player();
		Player(class SpriteAnimation** animationList, int count);
		virtual ~Player();

		void Update(float deltaTime);
		void Bind();
		void Draw();

		void SetScene(class GameScene* gameManager);
		bool CanMove(const XMFLOAT3& checkPosition, struct PlayerMovementCommandState* commandState);
		void AddAnimation(class SpriteAnimation* animation);
		void ChangeAnimation(const char* name);
		void SetTexture(Texture* texture);
		
		void SetPosition(const XMFLOAT3& position);
		void SetPosition(float x, float y, float z);
		void Translate(const XMFLOAT3& amount);
		void Translate(float x, float y, float z);

		// �÷��̾� �̵� Ƚ�� ���� �Լ�.
		void AddPlayerMovementCount();

		class Transform* GetTransform() const { return transform; }

	protected:
		class GameScene* scene = nullptr;
		class Transform* transform = nullptr;

		class Sprite* playerSprite = nullptr;
		
		Texture* currentTexture = nullptr;
		Texture* right = nullptr;
		Texture* left = nullptr;
		Texture* up = nullptr;
		Texture* down = nullptr;

		class SpriteAnimation* currentAnimation = nullptr;
		class PlayerMovement* movement = nullptr;
		std::unordered_map<std::string_view, class SpriteAnimation*> animations;
	};
}