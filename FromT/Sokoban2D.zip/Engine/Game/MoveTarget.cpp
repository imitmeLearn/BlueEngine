#include <PreCompiledHeader.h>
#include "MoveTarget.h"

namespace Ronnie
{
	MoveTarget::MoveTarget(const char* textureName)
		: Entity(textureName)
	{
		SetName("MoveTarget");
	}
}