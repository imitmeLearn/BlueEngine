#pragma once

namespace Ronnie
{
	class Entity
	{
	public:
		Entity(const char* textureName);
		Entity(class Texture* texture);
		virtual ~Entity();

		virtual void Update(float deltaTime);
		virtual void Draw();

		void SetName(const char* name);
		const char* GetName() const { return name; }

		class Transform* GetTransform() const { return transform; }

	protected:
		virtual void Bind();

	protected:
		char* name = nullptr;
		class Transform* transform = nullptr;
		class Sprite* sprite = nullptr;
	};
}