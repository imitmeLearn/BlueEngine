#include <PreCompiledHeader.h>
#include "Box.h"
#include <Math/Transform.h>
#include <Sprite/Sprite.h>

namespace Ronnie
{
	Box::Box(const char* textureName)
		: Entity(textureName)
	{
		SetName("Box");
	}
}