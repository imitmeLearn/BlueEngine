#pragma once

#include "Entity.h"

namespace Ronnie
{
	class Box : public Entity
	{
	public:
		Box(const char* textureName = "crate_02.png");
	};
}