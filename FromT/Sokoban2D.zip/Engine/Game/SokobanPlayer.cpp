#include <PreCompiledHeader.h>
#include "SokobanPlayer.h"
#include <Sprite/SpriteAnimation.h>
#include <Math/Transform.h>

namespace Ronnie
{
	SokokbanPlayer::SokokbanPlayer()
		: Player()
	{
		//const char* idleList[] =
		//{
		//	"player_09.png",
		//	"player_09.png",
		//	"player_09.png"
		//};

		//// Idle �ִϸ��̼� �߰�.
		//AddAnimation(new SpriteAnimation("Idle", idleList, _countof(idleList)));

		//const char* runList[] =
		//{
		//	"player_09.png",
		//	"player_10.png",
		//	"player_09.png",
		//	"player_11.png",
		//};
		//
		//// Run �ִϸ��̼� �߰�.
		//AddAnimation(new SpriteAnimation("Run", runList, _countof(runList)));

		//// ���� �ִϸ��̼� ����.
		//ChangeAnimation("Idle");

		// ������ ����.
		transform->SetScale(XMFLOAT3(0.9f, 1.0f, 1.0f));
	}

	SokokbanPlayer::~SokokbanPlayer()
	{
	}
}