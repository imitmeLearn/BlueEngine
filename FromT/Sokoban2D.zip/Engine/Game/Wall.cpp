#include <PreCompiledHeader.h>
#include "Wall.h"
#include <Math/Transform.h>
#include <Sprite/Sprite.h>

namespace Ronnie
{
	Wall::Wall(const char* textureName)
		: Entity(textureName)
	{
		SetName("Wall");
	}
}