#include <PreCompiledHeader.h>
#include "Ground.h"

namespace Ronnie
{
	Ground::Ground(const char* textureName)
		: Entity(textureName)
	{
		SetName("Ground");
	}
}