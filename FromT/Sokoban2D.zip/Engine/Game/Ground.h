#pragma once

#include "Entity.h"

namespace Ronnie
{
	class Ground : public Entity
	{
	public:
		Ground(const char* textureName = "ground_04.png");
	};
}