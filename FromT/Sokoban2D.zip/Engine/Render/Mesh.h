#pragma once

#include <PreCompiledHeader.h>
#include <Render/Vertex.h>

namespace Ronnie
{
	class Mesh
	{
	public:
		Mesh(std::vector<VertexPositionUV>& vertices);
		~Mesh();

		void Update();
		void Bind();

		uint32 VertexCount() const { return vertexCount; }
		uint32 VertexStride() const { return vertexStride; }
		uint32 IndexCount() const { return indexCount; }

	private:
		ID3D11Buffer* vertexBuffer = nullptr;
		void* vertexData = nullptr;
		uint32 vertexCount = 0u;
		uint32 vertexStride = 0u;
		
		ID3D11Buffer* indexBuffer = nullptr;
		void* indexData = nullptr;
		uint32 indexCount = 0u;
	};
}