#include <PreCompiledHeader.h>
#include "Material.h"
#include <Engine/Engine.h>
#include <Render/Texture.h>

namespace Ronnie
{
	int GetStringLength(const wchar_t* string)
	{
		int length = 0;
		wchar_t character = string[length];
		while (character != L'\0')
		{
			character = string[length++];
		}

		return length;
	}

	Material::Material(const wchar_t* shaderName)
	{
		size_t length = GetStringLength(shaderName);
		this->shaderName = new wchar_t[length + 1];
		memcpy(this->shaderName, shaderName, length * sizeof(wchar_t));
		this->shaderName[length] = L'\0';
	}

	Material::~Material()
	{
		SafeDelete(shaderName);
		SafeRelease(vertexShaderBuffer);
		SafeRelease(vertexShader);
		SafeRelease(pixelShaderBuffer);
		SafeRelease(pixelShader);
	}

	void Material::Initialize()
	{
		ID3DBlob* errorBlob = nullptr;
		ThrowIfFailed(D3DCompileFromFile(
			shaderName,
			nullptr,
			nullptr,
			"VSMain",
			"vs_5_0",
			0u,
			0u,
			&vertexShaderBuffer,
			&errorBlob
		), TEXT("Failed to compile vertex shader."));

		if (errorBlob)
		{
			const char* message = static_cast<const char*>(errorBlob->GetBufferPointer());
			MessageBoxA(nullptr, message, "Vertex Shader Error", MB_OK);
		}

		ThrowIfFailed(
			g_Engine->Device()->CreateVertexShader(vertexShaderBuffer->GetBufferPointer(), vertexShaderBuffer->GetBufferSize(), nullptr, &vertexShader),
			TEXT("Failed to create vertex shader."));

		ThrowIfFailed(D3DCompileFromFile(
			shaderName,
			nullptr,
			nullptr,
			"PSMain",
			"ps_5_0",
			0u,
			0u,
			&pixelShaderBuffer,
			&errorBlob
		), TEXT("Failed to compile pixel shader."));

		if (errorBlob)
		{
			const char* message = static_cast<const char*>(errorBlob->GetBufferPointer());
			MessageBoxA(nullptr, message, "Pixel Shader Error", MB_OK);
		}

		ThrowIfFailed(
			g_Engine->Device()->CreatePixelShader(pixelShaderBuffer->GetBufferPointer(), pixelShaderBuffer->GetBufferSize(), nullptr, &pixelShader),
			TEXT("Failed to create pixel shader."));

		SafeRelease(errorBlob);
	}
	
	void Material::Bind()
	{
		auto context = g_Engine->Context();
		context->VSSetShader(vertexShader, nullptr, 0u);
		context->PSSetShader(pixelShader, nullptr, 0u);

		if (texture != nullptr)
		{
			texture->Bind();
		}
	}

	void Material::SetTexture(Texture* texture)
	{
		this->texture = texture;
	}
}