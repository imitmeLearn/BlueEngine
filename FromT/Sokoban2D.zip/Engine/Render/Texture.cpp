#include <PreCompiledHeader.h>
#include "Texture.h"
#include <Engine/Engine.h>
#include <Resource/TextureManager.h>

namespace Ronnie
{
#include <Library/stb_image.h>
	Texture::Texture(const char* name)
	{
		// �ؽ�ó �̸� ����.
		size_t length = strlen(name) + 1;
		this->name = new char[length];
		strcpy_s(this->name, length, name);

		unsigned char* data = stbi_load(name, &width, &height, &channelCount, 0);

		// �ε� ���� �� ����.
		if (data == nullptr)
		{
			ThrowIfFailed(E_FAIL, TEXT("Failed to load StargeStartImage"));
		}

		// ��������Ʈ �ؽ�ó ����.
		D3D11_TEXTURE2D_DESC textureDesc = {};
		textureDesc.BindFlags = D3D11_BIND_SHADER_RESOURCE;
		textureDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM_SRGB;
		textureDesc.Width = width;
		textureDesc.Height = height;
		textureDesc.SampleDesc.Count = 1;
		textureDesc.SampleDesc.Quality = 0;
		textureDesc.ArraySize = 1;
		textureDesc.MipLevels = 1;

		D3D11_SUBRESOURCE_DATA textureData = {};
		textureData.pSysMem = data;
		textureData.SysMemPitch = width * channelCount;

		ID3D11Device* device = g_Engine->Device();

		ID3D11Texture2D* texture = nullptr;
		ThrowIfFailed(
			device->CreateTexture2D(&textureDesc, &textureData, &texture),
			TEXT("Failed to create Texture2D."));

		ThrowIfFailed(
			device->CreateShaderResourceView(texture, nullptr, &shaderResourceView),
			TEXT("Failed to create shader resrouce view."));

		SafeRelease(texture);
		SafeFree(data);

		// ���÷� ������Ʈ ����.
		D3D11_SAMPLER_DESC samplerDesc = {};
		samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
		samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
		samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
		samplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;

		ThrowIfFailed(
			device->CreateSamplerState(&samplerDesc, &samplerState),
			TEXT("Failed to create sampler state"));
	}

	Texture::Texture(const char* name, int width, int height, int channelCount, struct ID3D11ShaderResourceView* shaderResourceView)
		: width(width), height(height), channelCount(channelCount), shaderResourceView(shaderResourceView)
	{
		// �ؽ�ó �̸� ����.
		size_t length = strlen(name) + 1;
		this->name = new char[length];
		strcpy_s(this->name, length, name);

		// ���÷� ������Ʈ ����.
		D3D11_SAMPLER_DESC samplerDesc = {};
		samplerDesc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;
		samplerDesc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;
		samplerDesc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
		samplerDesc.Filter = D3D11_FILTER_MIN_MAG_MIP_POINT;

		ThrowIfFailed(
			g_Engine->Device()->CreateSamplerState(&samplerDesc, &samplerState),
			TEXT("Failed to create sampler state"));
	}

	Texture::~Texture()
	{
		// ���ҽ� ����.
		SafeDelete(name);
		SafeRelease(shaderResourceView);
		SafeRelease(samplerState);
	}

	void Texture::Bind(unsigned int index)
	{
		// �ؽ�ó ���ε�.
		auto context = g_Engine->Context();
		context->PSSetShaderResources(index, 1u, &shaderResourceView);
		context->PSSetSamplers(index, 1u, &samplerState);
	}
}