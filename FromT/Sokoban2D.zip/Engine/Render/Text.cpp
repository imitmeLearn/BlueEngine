#include <PreCompiledHeader.h>
#include <Engine/Engine.h>
#include "Text.h"


namespace Ronnie
{
	Text::Text(const wchar_t* name, float size, D2D1::ColorF color, float width, float height,
		DWRITE_FONT_WEIGHT fontWeight, DWRITE_FONT_STYLE fontStyle, DWRITE_FONT_STRETCH fontStretch)
		: textToDraw(nullptr), fontSize(size), fontColor(color), width(width), height(height), fontWeight(fontWeight), fontStyle(fontStyle), fontStretch(fontStretch)
	{
		int length = static_cast<int>(wcslen(name) + 1);
		fontName = new wchar_t[length];
		memcpy(fontName, name, sizeof(wchar_t) * length);
		fontName[length - 1] = '\0';

		auto result = g_Engine->DWriteFactory()->CreateTextFormat(fontName, nullptr, fontWeight, fontStyle, fontStretch, fontSize, TEXT("ko"), &format);
		ThrowIfFailed(result, TEXT("Failed to create text format."));

		result = g_Engine->DWriteRenderTarget()->CreateSolidColorBrush(fontColor, &brush);
		ThrowIfFailed(result, TEXT("Failed to create direct2d brush."));
	}

	Text::~Text()
	{
		SafeDelete(fontName);

		SafeRelease(brush);
		SafeRelease(layout);
		SafeRelease(format);

		SafeDelete(textToDraw);
	}

	void Text::SetText(const wchar_t* newText)
	{
		SafeDelete(textToDraw);

		int length = static_cast<int>(wcslen(newText) + 1);
		textToDraw = new wchar_t[length];
		memcpy(textToDraw, newText, sizeof(wchar_t) * length);
		textToDraw[length - 1] = '\0';

		ThrowIfFailed(
			g_Engine->DWriteFactory()->CreateTextLayout(textToDraw, static_cast<uint32>(wcslen(textToDraw)), format, width, height, &layout),
			TEXT("Failed to create text layout."));

		ThrowIfFailed(layout->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_CENTER), TEXT("Failed to set text alignment."));
	}

	void Text::Draw(D2D1_POINT_2F fontPosition)
	{
		if (textToDraw == nullptr)
		{
			return;
		}

		SafeRelease(layout);

		ThrowIfFailed(
			g_Engine->DWriteFactory()->CreateTextLayout(textToDraw, static_cast<uint32>(wcslen(textToDraw)), format, width, height, &layout),
			TEXT("Failed to create text layout."));

		if (layout != nullptr)
		{
			g_Engine->DWriteRenderTarget()->DrawTextLayout(fontPosition, layout, brush);
		}
	}

	void Text::SetWidth(float width)
	{
		this->width = width;
	}

	float Text::Width() const
	{
		return width;
	}

	void Text::SetHeight(float height)
	{
		this->height = height;
	}

	float Text::Height() const
	{
		return height;
	}

	float Text::LayoutWidth() const
	{
		if (layout == nullptr)
		{
			return 0.0f;
		}

		DWRITE_TEXT_METRICS metrics;
		ThrowIfFailed(layout->GetMetrics(&metrics), TEXT("Failed to get IDWriteTextLayout::GetMetrics"));

		return metrics.width;
	}

	float Text::LayoutHeight() const
	{
		if (layout == nullptr)
		{
			return 0.0f;
		}

		DWRITE_TEXT_METRICS metrics;
		ThrowIfFailed(layout->GetMetrics(&metrics), TEXT("Failed to get IDWriteTextLayout::GetMetrics"));
		
		return metrics.height;
	}

	const wchar_t* Text::FontName() const
	{
		return fontName;
	}

	void Text::SetFontColor(const D2D1::ColorF& fontColor)
	{
		ThrowIfFailed(
			g_Engine->DWriteRenderTarget()->CreateSolidColorBrush(fontColor, &brush),
			TEXT("Failed to create direct2d brush."));
	}

	void Text::SetFontSize(float fontSize)
	{
		this->fontSize = fontSize;

		SafeRelease(format);

		ThrowIfFailed(
			g_Engine->DWriteFactory()->CreateTextFormat(fontName, nullptr, fontWeight, fontStyle, fontStretch, fontSize, TEXT("ko"), &format),
			TEXT("Failed to create text format."));
	}
	
	float Text::FontSize() const
	{
		return fontSize;
	}
}