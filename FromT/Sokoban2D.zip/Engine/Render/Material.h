#pragma once

#include <PreCompiledHeader.h>

namespace Ronnie
{
	class Material
	{
	public:
		Material(const wchar_t* shaderName);
		virtual ~Material();

		virtual void Initialize();
		virtual void Bind();

		class Texture* GetTexture() const { return texture; }
		void SetTexture(class Texture* texture);

	protected:

		wchar_t* shaderName;

		ID3DBlob* vertexShaderBuffer = nullptr;
		ID3D11VertexShader* vertexShader = nullptr;
		ID3DBlob* pixelShaderBuffer = nullptr;
		ID3D11PixelShader* pixelShader = nullptr;

		class Texture* texture = nullptr;
	};
}