#pragma once

#include <DirectXMath.h>

namespace Ronnie
{
	using namespace DirectX;

	struct CameraBuffer
	{
		XMMATRIX viewMatrix = XMMatrixIdentity();
		XMMATRIX projectionMatrix = XMMatrixIdentity();
	};

	class Camera
	{
	public:
		Camera(unsigned int width, unsigned int height, float fieldOfView, float nearDistance, float farDistance);
		~Camera();

		void Update();
		void Bind();
		void OnResize(unsigned int width, unsigned int height);

		class Transform* GetTransform() const { return transform; }

	private:
		XMMATRIX viewMatrix = XMMatrixIdentity();
		XMMATRIX projectionMatrix = XMMatrixIdentity();

		float fieldOfView = 60.0f;
		float nearDistance = 0.1f;
		float farDistance = 1000.0f;
		//float orthographicSize = 15.0f;
		float orthographicSize = 20.0f;
		float originalOrthographicSize = 0.0f;
		unsigned int width = 0u;
		unsigned int height = 0u;

		class Transform* transform = nullptr;
		struct ID3D11Buffer* cameraBuffer = nullptr;
	};
}