#pragma once

#include <string_view>

namespace Ronnie
{
	class Texture
	{
	public:
		Texture(const char* name);
		Texture(const char* name, int width, int height, int channelCount, struct ID3D11ShaderResourceView* shaderResourceView);
		virtual ~Texture();

		virtual void Bind(unsigned int index = 0u);
		
		const char* Name() const { return name; }
		int Width() const { return width; }
		int Height() const { return height; }
		int ChannelCount() const { return channelCount; }

	protected:
		char* name;
		int width = 0;
		int height = 0;
		int channelCount = 0;

		struct ID3D11ShaderResourceView* shaderResourceView = nullptr;
		struct ID3D11SamplerState* samplerState = nullptr;
	};
}