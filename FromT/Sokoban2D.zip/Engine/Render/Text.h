#pragma once

#include <d2d1.h>
#include <dwrite.h>

namespace Ronnie
{
	class Text
	{
	public:
		Text(const wchar_t* name = TEXT("Jetbrains Mono"), float size = 18.0f, D2D1::ColorF color = D2D1::ColorF::White,
			float width = 300.0f, float height = 200.0f,
			DWRITE_FONT_WEIGHT fontWeight = DWRITE_FONT_WEIGHT::DWRITE_FONT_WEIGHT_BOLD,
			DWRITE_FONT_STYLE fontStyle = DWRITE_FONT_STYLE::DWRITE_FONT_STYLE_NORMAL,
			DWRITE_FONT_STRETCH fontStretch = DWRITE_FONT_STRETCH::DWRITE_FONT_STRETCH_NORMAL);

		virtual ~Text();

		void SetText(const wchar_t* newText);
		void Draw(D2D1_POINT_2F fontPosition);

		const wchar_t* FontName() const;

		void SetFontColor(const D2D1::ColorF& fontColor);

		void SetFontSize(float fontSize);
		float FontSize() const;

		void SetWidth(float width);
		float Width() const;

		void SetHeight(float height);
		float Height() const;

		float LayoutWidth() const;
		float LayoutHeight() const;

	private:
		wchar_t* textToDraw = nullptr;

		ID2D1SolidColorBrush* brush = nullptr;
		IDWriteTextLayout* layout = nullptr;
		IDWriteTextFormat* format = nullptr;

		wchar_t* fontName;
		DWRITE_FONT_WEIGHT fontWeight;
		DWRITE_FONT_STYLE fontStyle;
		DWRITE_FONT_STRETCH fontStretch;
		float fontSize;
		D2D1::ColorF fontColor;
		float width;
		float height;
	};
}