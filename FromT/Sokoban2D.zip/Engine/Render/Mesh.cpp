#include <PreCompiledHeader.h>
#include "Mesh.h"
#include <Engine/Engine.h>
#include <Math/Transform.h>

namespace Ronnie
{
	Mesh::Mesh(std::vector<VertexPositionUV>& vertices)
	{
		vertexData = reinterpret_cast<VertexPositionUV*>(vertices.data());
		vertexCount = static_cast<uint32>(vertices.size());
		vertexStride = sizeof(VertexPositionUV);

		auto device = g_Engine->Device();

		D3D11_BUFFER_DESC vertexBufferDesc = {};
		vertexBufferDesc.ByteWidth = vertexStride * vertexCount;
		vertexBufferDesc.BindFlags = D3D11_BIND_VERTEX_BUFFER;

		D3D11_SUBRESOURCE_DATA vertexBufferData = {};
		vertexBufferData.pSysMem = vertexData;

		ThrowIfFailed(
			device->CreateBuffer(&vertexBufferDesc, &vertexBufferData, &vertexBuffer), 
			TEXT("Failed to create vertex buffer."));

		std::vector<uint32> indices;
		for (int ix = 0; ix < vertices.size(); ++ix)
		{
			indices.emplace_back(ix);
		}

		indexData = reinterpret_cast<void*>(indices.data());
		indexCount = static_cast<uint32>(indices.size());

		D3D11_BUFFER_DESC indexBufferDesc = {};
		indexBufferDesc.ByteWidth = sizeof(uint32) * indexCount;
		indexBufferDesc.BindFlags = D3D11_BIND_INDEX_BUFFER;

		D3D11_SUBRESOURCE_DATA indexBufferData = {};
		indexBufferData.pSysMem = indexData;

		ThrowIfFailed(
			device->CreateBuffer(&indexBufferDesc, &indexBufferData, &indexBuffer),
			TEXT("Failed to create index buffer."));
	}

	Mesh::~Mesh()
	{
		SafeRelease(vertexBuffer);
		SafeRelease(indexBuffer);
	}

	void Mesh::Update()
	{
	}

	void Mesh::Bind()
	{
		auto context = g_Engine->Context();
		
		static uint32 stride = vertexStride;
		static uint32 offset = 0u;
		context->IASetVertexBuffers(0u, 1u, &vertexBuffer, &stride, &offset);
		context->IASetIndexBuffer(indexBuffer, DXGI_FORMAT_R32_UINT, 0u);
		context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	}
}