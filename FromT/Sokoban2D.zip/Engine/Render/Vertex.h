#pragma once

#include <DirectXMath.h>

namespace Ronnie
{
	using namespace DirectX;

	class VertexPosition
	{
	public:
		VertexPosition() = default;
		VertexPosition(const XMFLOAT3& position)
			: position(position)
		{
		}

		XMFLOAT3 position;
	};

	class VertexPositionUV
	{
	public:
		VertexPositionUV() = default;
		VertexPositionUV(const XMFLOAT3& position, const XMFLOAT2& uv)
			: position(position), uv(uv)
		{
		}

		XMFLOAT3 position;
		XMFLOAT2 uv;
	};
}