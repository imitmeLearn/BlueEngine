#pragma once

#include <string>

namespace Ronnie
{
	class SpriteData
	{
	public:
		SpriteData(const char* nameValue , const char* xValue, const char* yValue, const char* widthValue, const char* heightValue)
		{
			x = atoi(xValue);
			y = atoi(yValue);
			width = atoi(widthValue);
			height = atoi(heightValue);
			name = new char[strlen(nameValue) + 1];
			strcpy_s(name, strlen(nameValue) + 1, nameValue);
		}

		SpriteData(const char* name, int x, int y, int width, int height)
			: x(x), y(y), width(width), height(height)
		{
			this->name = new char[strlen(name) + 1];
			strcpy_s(this->name, strlen(name) + 1, name);
		}

		~SpriteData()
		{
			if (name != nullptr)
			{
				delete name;
				name = nullptr;
			}
		}

		//const char* ToString()
		void Print()
		{
			char buffer[100];
			sprintf_s(buffer, "name: %s, x: %d, y: %d, width: %d, height: %d", name, x, y, width, height);
			std::cout << buffer << "\n";
			//buffer[99] = 0;
			//return (const char*)buffer;
		}

		char* name = nullptr;
		unsigned int x = 0u;
		unsigned int y = 0u;
		unsigned int width = 0u;
		unsigned int height = 0u;
	};

	class Sprite
	{
	public:
		Sprite(const char* textureName);
		Sprite(class Texture* texture);
		virtual ~Sprite();

		void SetTexture(class Texture* texture);

		virtual void Update(float deltaTime);
		virtual void Bind();

		unsigned int IndexCount() const;

	protected:
		class Mesh* mesh = nullptr;
		class Material* material = nullptr;
	};
}