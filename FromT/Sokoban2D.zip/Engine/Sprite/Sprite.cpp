#include <PreCompiledHeader.h>
#include "Sprite.h"
#include <Material/DefaultMaterial.h>
#include <Render/Texture.h>
#include <Math/Transform.h>
#include <Render/Vertex.h>
#include <Render/Mesh.h>
#include <Resource/TextureManager.h>

#include <DirectXMath.h>

namespace Ronnie
{
	using namespace DirectX;

	Sprite::Sprite(const char* textureName)
	{
		material = new DefaultMaterial();
		material->Initialize();
		material->SetTexture(TextureManager::LoadTexture(textureName));

		std::vector<VertexPositionUV> vertices =
		{
			VertexPositionUV(XMFLOAT3(-0.5f, -0.5f, +0.0f), XMFLOAT2(0.0f, 1.0f)),
			VertexPositionUV(XMFLOAT3(-0.5f, +0.5f, +0.0f), XMFLOAT2(0.0f, 0.0f)),
			VertexPositionUV(XMFLOAT3(+0.5f, +0.5f, +0.0f), XMFLOAT2(1.0f, 0.0f)),

			VertexPositionUV(XMFLOAT3(-0.5f, -0.5f, +0.0f), XMFLOAT2(0.0f, 1.0f)),
			VertexPositionUV(XMFLOAT3(+0.5f, +0.5f, +0.0f), XMFLOAT2(1.0f, 0.0f)),
			VertexPositionUV(XMFLOAT3(+0.5f, -0.5f, +0.0f), XMFLOAT2(1.0f, 1.0f)),
		};

		mesh = new Mesh(vertices);
	}

	Sprite::Sprite(Texture* texture)
	{
		material = new DefaultMaterial();
		material->Initialize();
		material->SetTexture(texture);

		std::vector<VertexPositionUV> vertices =
		{
			VertexPositionUV(XMFLOAT3(-0.5f, -0.5f, +0.0f), XMFLOAT2(0.0f, 1.0f)),
			VertexPositionUV(XMFLOAT3(-0.5f, +0.5f, +0.0f), XMFLOAT2(0.0f, 0.0f)),
			VertexPositionUV(XMFLOAT3(+0.5f, +0.5f, +0.0f), XMFLOAT2(1.0f, 0.0f)),

			VertexPositionUV(XMFLOAT3(-0.5f, -0.5f, +0.0f), XMFLOAT2(0.0f, 1.0f)),
			VertexPositionUV(XMFLOAT3(+0.5f, +0.5f, +0.0f), XMFLOAT2(1.0f, 0.0f)),
			VertexPositionUV(XMFLOAT3(+0.5f, -0.5f, +0.0f), XMFLOAT2(1.0f, 1.0f)),
		};

		mesh = new Mesh(vertices);
	}

	Sprite::~Sprite()
	{
		SafeDelete(mesh);
		SafeDelete(material);
	}

	void Sprite::SetTexture(Texture* texture)
	{
		material->SetTexture(texture);
	}

	void Sprite::Update(float deltaTime)
	{
		mesh->Update();
	}

	void Sprite::Bind()
	{
		material->Bind();
		mesh->Bind();
	}

	unsigned int Sprite::IndexCount() const
	{
		return mesh->IndexCount();
	}
}