#pragma once

#include <vector>
#include "Sprite.h"

namespace Ronnie
{
	class SpriteAnimation : public Sprite
	{
		friend class Player;

	public:
		SpriteAnimation(const char* name, const char** textureNameList, int frameCount);
		~SpriteAnimation();

		virtual void Update(float deltaTime) override;
		virtual void Bind() override;
		virtual void Reset();

		void SetAnimationActive(bool active);

	private:

		char* name;

		std::vector<class Texture*> textures;
		int spriteAnimationIndex = 0;
		int frameCount = 0;
		float elapsedTime = 0.0f;
		float oneFrameTime = 0.0f;
		float animationSpeed = 1.0f;
		bool isAnimating = true;
	};
}