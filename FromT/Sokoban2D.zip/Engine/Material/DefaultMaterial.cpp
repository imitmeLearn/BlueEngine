#include <PreCompiledHeader.h>
#include "DefaultMaterial.h"
#include <Engine/Engine.h>

namespace Ronnie
{
	DefaultMaterial::DefaultMaterial()
		: Material(TEXT("D3D11Shader/DefaultShader.hlsl"))
	{
	}
	
	DefaultMaterial::~DefaultMaterial()
	{
		SafeRelease(inputlayout);
	}
	
	void DefaultMaterial::Initialize()
	{
		Material::Initialize();
		D3D11_INPUT_ELEMENT_DESC inputElementDesc[] =
		{
			{ "POSITION", 0u, DXGI_FORMAT_R32G32B32_FLOAT, 0u, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0u },
			{ "TEXCOORD", 0u, DXGI_FORMAT_R32G32_FLOAT, 0u, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0u }
		};

		ThrowIfFailed(
			g_Engine->Device()->CreateInputLayout(
				inputElementDesc, 
				_countof(inputElementDesc), 
				vertexShaderBuffer->GetBufferPointer(), 
				vertexShaderBuffer->GetBufferSize(), 
				&inputlayout),
			TEXT("Failed to create input layout"));
	}

	void DefaultMaterial::Bind()
	{
		Material::Bind();
		g_Engine->Context()->IASetInputLayout(inputlayout);
	}
}