#pragma once

#include <Render/Material.h>

namespace Ronnie
{
	class DefaultMaterial : public Material
	{
	public:
		DefaultMaterial();
		~DefaultMaterial();

		virtual void Initialize() override;
		virtual void Bind() override;

	private:
		ID3D11InputLayout* inputlayout = nullptr;
	};
}