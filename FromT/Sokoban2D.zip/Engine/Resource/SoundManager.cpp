#include <PreCompiledHeader.h>
#include "SoundManager.h"

namespace Ronnie
{
	SoundManager::SoundManager()
	{
		unsigned int flag = 0u;
#if _DEBUG
		flag |= XAUDIO2_DEBUG_ENGINE;
#endif

		ThrowIfFailed(
			XAudio2Create(&xAudio2, flag, XAUDIO2_DEFAULT_PROCESSOR),
			TEXT("Failed to create xaudio2"));

		ThrowIfFailed(
			xAudio2->CreateMasteringVoice(&masterVoice),
			TEXT("Failed to create mastering voice with xaudio2")
		);
	}

	SoundManager::~SoundManager()
	{
		if (masterVoice != nullptr)
		{
			masterVoice->DestroyVoice();
		}
		
		SafeRelease(xAudio2);
	}

	void SoundManager::SetVolume(float volume)
	{
		masterVoice->SetVolume(volume);
	}

	IXAudio2* SoundManager::XAudio2Engine()
	{
		return xAudio2;
	}
	
	IXAudio2MasteringVoice* SoundManager::MasterVoice()
	{
		return masterVoice;
	}
}