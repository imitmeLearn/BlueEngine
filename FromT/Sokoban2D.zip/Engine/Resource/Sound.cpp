#include <PreCompiledHeader.h>
#include "SoundManager.h"
#include "Sound.h"
#include <Engine/Engine.h>

#define fourccRIFF 'FFIR'
#define fourccDATA 'atad'
#define fourccFMT ' tmf'
#define fourccWAVE 'EVAW'
#define fourccXWMA 'AMWX'
#define fourccDPDS 'sdpd'

namespace Ronnie
{
	Sound::Sound(const wchar_t* filename)
		: loop(true)
	{
		HRESULT result;
		fileHandle = CreateFile(filename, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
		if (fileHandle == INVALID_HANDLE_VALUE)
		{
			result = HRESULT_FROM_WIN32(GetLastError());
		}

		if (SetFilePointer(fileHandle, 0, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER)
		{
			result = HRESULT_FROM_WIN32(GetLastError());
		}

		DWORD dwChunkSize;
		DWORD dwChunkPosition;
		ThrowIfFailed(
			FindChunk(fileHandle, fourccRIFF, dwChunkSize, dwChunkPosition),
			TEXT("Failed to find chunk in Sound::Sound()"));

		DWORD fileType;
		ThrowIfFailed(
			ReadChunkData(fileHandle, &fileType, sizeof(DWORD), dwChunkPosition),
			TEXT("Failed to read chunk data in Sound::Sound()"));

		if (fileType != fourccWAVE)
		{
			ThrowIfFailed(E_FAIL, TEXT("audio file type is invalid. it should be wav format but it is not."));
		}

		waveFormat = {};
		buffer = {};

		ThrowIfFailed(
			FindChunk(fileHandle, fourccFMT, dwChunkSize, dwChunkPosition),
			TEXT("Failed to find chunk in Sound::Sound()"));

		ThrowIfFailed(
			ReadChunkData(fileHandle, &waveFormat, dwChunkSize, dwChunkPosition),
			TEXT("Failed to read chunk data in Sound::Sound()"));

		ThrowIfFailed(
			FindChunk(fileHandle, fourccDATA, dwChunkSize, dwChunkPosition),
			TEXT("Failed to find chunk in Sound::Sound()"));

		BYTE* dataBuffer = new BYTE[dwChunkSize];
		ThrowIfFailed(
			ReadChunkData(fileHandle, dataBuffer, dwChunkSize, dwChunkPosition),
			TEXT("Failed to read chunk data in Sound::Sound()"));

		buffer.AudioBytes = dwChunkSize;
		buffer.pAudioData = dataBuffer;
		buffer.Flags = XAUDIO2_END_OF_STREAM;
		buffer.LoopCount = XAUDIO2_LOOP_INFINITE;
	}

	Sound::~Sound()
	{
		//if (sourceVoice != nullptr)
		//{
		//	sourceVoice->Stop();
		//	sourceVoice->DestroyVoice();
		//}

		CloseHandle(fileHandle);
	}

	void Sound::Play()
	{
		if (sourceVoice == nullptr)
		{
			ThrowIfFailed(
				g_Engine->GetAudioManager()->XAudio2Engine()->CreateSourceVoice(&sourceVoice, &waveFormat),
				TEXT("Failed to create source voice."));
		}
		else
		{
			sourceVoice->Stop();
			sourceVoice->FlushSourceBuffers();
		}

		ThrowIfFailed(
			sourceVoice->SubmitSourceBuffer(&buffer),
			TEXT("Failed to submit source buffer."));

		ThrowIfFailed(
			sourceVoice->Start(),
			TEXT("Failed to start source voice."));
	}

	void Sound::Stop()
	{
		if (sourceVoice != nullptr)
		{
			sourceVoice->Stop();
			sourceVoice->FlushSourceBuffers();
		}
	}

	HRESULT Sound::FindChunk(HANDLE fileHandle, DWORD fourcc, DWORD& chunkSize, DWORD& chunkDataPosition)
	{
		HRESULT result = S_OK;
		if (SetFilePointer(fileHandle, 0, NULL, FILE_BEGIN) == INVALID_SET_FILE_POINTER)
		{
			return HRESULT_FROM_WIN32(GetLastError());
		}

		DWORD dwChunkType;
		DWORD dwChunkDataSize;
		DWORD dwRIFFDataSize = 0;
		DWORD dwFileType;
		DWORD bytesRead = 0;
		DWORD dwOffset = 0;

		while (result == S_OK)
		{
			DWORD dwRead;
			if (ReadFile(fileHandle, &dwChunkType, sizeof(DWORD), &dwRead, NULL) == FALSE)
			{
				result = HRESULT_FROM_WIN32(GetLastError());
			}

			if (ReadFile(fileHandle, &dwChunkDataSize, sizeof(DWORD), &dwRead, NULL) == FALSE)
			{
				result = HRESULT_FROM_WIN32(GetLastError());
			}

			switch (dwChunkType)
			{
			case fourccRIFF:
				dwRIFFDataSize = dwChunkDataSize;
				dwChunkDataSize = 4;
				if (ReadFile(fileHandle, &dwFileType, sizeof(DWORD), &dwRead, NULL) == FALSE)
				{
					result = HRESULT_FROM_WIN32(GetLastError());
				}

				break;

			default:
				if (SetFilePointer(fileHandle, dwChunkDataSize, NULL, FILE_CURRENT) == INVALID_SET_FILE_POINTER)
				{
					return HRESULT_FROM_WIN32(GetLastError());
				}
			}

			dwOffset += sizeof(DWORD) * 2;

			if (dwChunkType == fourcc)
			{
				chunkSize = dwChunkDataSize;
				chunkDataPosition = dwOffset;
				return S_OK;
			}

			dwOffset += dwChunkDataSize;

			if (bytesRead >= dwRIFFDataSize)
			{
				return S_FALSE;
			}
		}

		return S_OK;
	}

	HRESULT Sound::ReadChunkData(HANDLE fileHandle, void* buffer, DWORD bufferSize, DWORD bufferOffset)
	{
		HRESULT result = S_OK;
		if (INVALID_SET_FILE_POINTER == SetFilePointer(fileHandle, bufferOffset, NULL, FILE_BEGIN))
		{
			return HRESULT_FROM_WIN32(GetLastError());
		}

		DWORD dwRead;
		if (ReadFile(fileHandle, buffer, bufferSize, &dwRead, NULL) == FALSE)
		{
			result = HRESULT_FROM_WIN32(GetLastError());
		}

		return result;
	}
}