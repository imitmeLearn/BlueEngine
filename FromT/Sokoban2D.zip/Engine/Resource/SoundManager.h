#pragma once

#include <xaudio2.h>

namespace Ronnie
{
	class SoundManager
	{
	public:
		SoundManager();
		virtual ~SoundManager();

		void SetVolume(float volume);

		IXAudio2* XAudio2Engine();
		IXAudio2MasteringVoice* MasterVoice();

	private:
		float scale = 1.0f;
		IXAudio2* xAudio2 = nullptr;
		IXAudio2MasteringVoice* masterVoice = nullptr;
	};
}