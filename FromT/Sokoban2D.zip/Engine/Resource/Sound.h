#pragma once

#include <xaudio2.h>

namespace Ronnie
{
	class Sound
	{
	public:
		Sound(const wchar_t* filename);
		~Sound();

		void Play();
		void Stop();

	private:
		HRESULT FindChunk(HANDLE fileHandle, DWORD fourcc, DWORD& chunkSize, DWORD& chunkPosition);
		HRESULT ReadChunkData(HANDLE fileHandle, void* buffer, DWORD bufferSize, DWORD bufferOffset);

	private:
		bool loop = false;
		HANDLE fileHandle = nullptr;
		IXAudio2SourceVoice* sourceVoice = nullptr;
		WAVEFORMATEX waveFormat;
		XAUDIO2_BUFFER buffer;
	};
}