#pragma once

#include <unordered_map>
#include <string_view>

namespace Ronnie
{
	class Texture;
	class TextureManager
	{
	public:
		static Texture* LoadTexture(const char* name);
		static void Initialize();
		static void Release();

	private:
		static std::unordered_map<std::string_view, class SpriteData*> spriteInfo;
		static std::unordered_map<std::string_view, Texture*> textures;

		static int textureWidth;
		static int textureHeight;
		static int channelCount;
		static unsigned char* data;
	};
}