#pragma once

#include <vector>
#include <queue>

namespace Ronnie
{
	class Command;
	class CommandManager
	{
	public:
		CommandManager();
		~CommandManager();

		void AddCommand(Command* command, bool execute = true);
		
		void Undo();
		void Redo();

	private:
		void ResetAllRecords();

	private:

		std::vector<Command*> commandHistory;
		int counter = 0;
	};
}