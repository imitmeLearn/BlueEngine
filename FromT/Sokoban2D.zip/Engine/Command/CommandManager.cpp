#include <PreCompiledHeader.h>
#include "CommandManager.h"
#include "Command.h"
#include <algorithm>

namespace Ronnie
{
	CommandManager::CommandManager()
	{
	}

	CommandManager::~CommandManager()
	{
		for (Command* command : commandHistory)
		{
			SafeDelete(command);
		}
	}

	void CommandManager::AddCommand(Command* command, bool execute)
	{
		while (static_cast<int>(commandHistory.size()) > counter)
		{
			Command* command = commandHistory[counter];
			auto search = std::find(commandHistory.begin(), commandHistory.end(), command);
			if (search != commandHistory.end())
			{
				commandHistory.erase(search);
			}
		}

		if (execute == true)
		{
			command->Do();
		}
		
		commandHistory.emplace_back(command);
		++counter;
	}

	void CommandManager::Undo()
	{
		if (counter > 0)
		{
			--counter;
			commandHistory[counter]->Undo();
		}
	}

	void CommandManager::Redo()
	{
		if (counter < static_cast<int>(commandHistory.size()))
		{
			commandHistory[counter]->Do();
			++counter;
		}
	}
	
	void CommandManager::ResetAllRecords()
	{
		for (Command* command : commandHistory)
		{
			SafeDelete(command);
		}

		commandHistory.clear();
	}
}