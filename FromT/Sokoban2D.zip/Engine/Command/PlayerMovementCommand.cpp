#include <PreCompiledHeader.h>
#include "PlayerMovementCommand.h"
#include <Game/Entity.h>
#include <Game/Player.h>
#include <Game/Box.h>
#include <Render/Texture.h>
#include <Math/Transform.h>

namespace Ronnie
{
	PlayerMovementCommand::PlayerMovementCommand(PlayerMovementCommandState* commandState)
		: commandState(commandState)
	{
	}

	PlayerMovementCommand::~PlayerMovementCommand()
	{
		SafeDelete(commandState);
	}

	void PlayerMovementCommand::AddBoxPosition(Entity* box, const XMFLOAT3& boxCurrentPosition, const XMFLOAT3& boxNewPosition)
	{
		if (commandState == nullptr)
		{
			return;
		}

		commandState->box = box;
		commandState->boxCurrentPosition = boxCurrentPosition;
		commandState->boxNewPosition = boxNewPosition;
	}

	void PlayerMovementCommand::Do()
	{
		if (commandState == nullptr)
		{
			return;
		}

		Player* player = commandState->player;
		player->SetPosition(commandState->playerNewPosition);
		player->SetTexture(commandState->playerNewTexture);

		if (commandState->box != nullptr)
		{
			commandState->box->GetTransform()->SetPosition(commandState->boxNewPosition);
		}
	}

	void PlayerMovementCommand::Undo()
	{
		if (commandState == nullptr)
		{
			return;
		}

		Player* player = commandState->player;
		player->SetPosition(commandState->playerCurrentPosition);
		player->SetTexture(commandState->playerCurrentTexture);

		if (commandState->box != nullptr)
		{
			commandState->box->GetTransform()->SetPosition(commandState->boxCurrentPosition);
		}
	}
}