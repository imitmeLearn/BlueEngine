#pragma once

#include "Command.h"
#include <DirectXMath.h>

namespace Ronnie
{
	using namespace DirectX;

	class Player;
	class Entity;
	class Texture;
	struct PlayerMovementCommandState
	{
		Player* player = nullptr;

		Texture* playerCurrentTexture = nullptr;
		Texture* playerNewTexture = nullptr;
		
		XMFLOAT3 playerCurrentPosition = XMFLOAT3(0.0f, 0.0f, 0.0f);
		XMFLOAT3 playerNewPosition = XMFLOAT3(0.0f, 0.0f, 0.0f);

		Entity* box = nullptr;
		XMFLOAT3 boxCurrentPosition = XMFLOAT3(0.0f, 0.0f, 0.0f);
		XMFLOAT3 boxNewPosition = XMFLOAT3(0.0f, 0.0f, 0.0f);
	};
	
	class PlayerMovementCommand : public Command
	{
	public:
		PlayerMovementCommand(PlayerMovementCommandState* commandState);
		~PlayerMovementCommand();

		void AddBoxPosition(Entity* box, const XMFLOAT3& boxCurrentPosition, const XMFLOAT3& boxNewPosition);

		virtual void Do() override;
		virtual void Undo() override;

	private:
		PlayerMovementCommandState* commandState = nullptr;
	};
}