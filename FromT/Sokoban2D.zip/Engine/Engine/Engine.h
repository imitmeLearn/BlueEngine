#pragma once

#include <Device/Window.h>

#include <d2d1.h>
#include <dwrite.h>

namespace Ronnie
{
	struct EngineSetup
	{
		EngineSetup() = default;
		EngineSetup(uint32 width, uint32 height, const wchar_t* title)
			: width(width), height(height)
		{
			int length = static_cast<int>(wcslen(title) + 1);
			this->title = new wchar_t[length];
			memcpy(this->title, title, sizeof(wchar_t) * length);
			this->title[length - 1] = '\0';
		}

		~EngineSetup()
		{
			SafeDelete(title);
		}

		uint32 width;
		uint32 height;
		wchar_t* title;
	};

	class Engine
	{
		friend class RHI;

	public:
		Engine(EngineSetup* setup);
		~Engine();

		void Run();
		void Update();
		void OnResize(uint32 width, uint32 height);
		void SetActive(bool active);

		void ChangeScene(int newSceneIndex);
		void ResumeGame();
		void QuitGame();

		uint32 Width() const { return setup->width; }
		uint32 Height() const { return setup->height; }

		void AddCommand(class Command* command, bool execute = true);
		void Undo();
		void Redo();

		ID3D11Device* Device() const { return device; }
		ID3D11DeviceContext* Context() const { return deviceContext; }
		IDWriteFactory* DWriteFactory() const { return dwFactory; }
		ID2D1RenderTarget* DWriteRenderTarget() const { return d2dRenderTarget; }
		class SoundManager* GetAudioManager() const { return soundManager; }

	private:
		
		// D2D ��ġ �ʱ�ȭ.
		void InitializeDirect2DDevices();

		void ProcessInput();
		void Update(float deltaTime);
		
		void Draw();
		void BeginScene();
		void DrawScene();
		void EndScene();

	private:

		// Engine Base.
		EngineSetup* setup = nullptr;
		Window* window = nullptr;
		class SoundManager* soundManager = nullptr;
		class CommandManager* commandManager = nullptr;

		bool isActive = true;

		// ���� �������Ǵ� �� �ε���.
		int currentSceneIndex = 0;

		// ��ü ���Ӿ� �迭.
		std::vector<class Scene*> scenes;

		// �޴� ��.
		class MenuScene* menuScene = nullptr;
		
		// ���� �޴� ���� ������ ������ Ȯ���ϴ� �� ����ϴ� ����.
		bool isMenuSceneRendering = false;

		// ī�޶�.
		class Camera* camera = nullptr;

		// Time.
		class EngineTime* timer = nullptr;
		float targetFrameRate = 120.0f;
		int32 framesPerSecond = 0;
		float elapsedTime = 0.f;
		bool isVsync = false;

		// Render Hardware Interface.
		ID3D11Device* device = nullptr;
		ID3D11DeviceContext* deviceContext = nullptr;
		IDXGISwapChain* swapChain = nullptr;
		ID3D11RenderTargetView* renderTargetView = nullptr;
		ID3D11DepthStencilState* depthStencilState = nullptr;
		ID3D11DepthStencilView* depthStencilView = nullptr;
		ID3D11BlendState* blendState = nullptr;
		ID3D11RasterizerState* rasterizerState = nullptr;

		// Direct2D(Text �������� ��� ��).
		ID2D1Factory* d2dFactory = nullptr;
		IDWriteFactory* dwFactory = nullptr;
		ID2D1RenderTarget* d2dRenderTarget = nullptr;
	};
}

extern Ronnie::Engine* g_Engine;