#include <PreCompiledHeader.h>

#include <Device/Input.h>

#include "Engine.h"

#include <Device/EngineTime.h>
#include <Render/Mesh.h>
#include <Material/DefaultMaterial.h>

#include <DirectXMath.h>
#include <Math/Transform.h>
#include <Render/Camera.h>
#include <Render/Texture.h>

#include <Sprite/Sprite.h>
#include <Sprite/SpriteAnimation.h>

#include <Resource/TextureManager.h>
#include <Resource/SoundManager.h>
#include <Command/CommandManager.h>

#include <Game/Scene/MenuScene.h>
#include <Game/Scene/GameScene.h>
#include <Game/Scene/StartScene.h>
#include <Game/SokobanPlayer.h>

#include <Render/Text.h>

namespace Ronnie
{
	using namespace DirectX;

	Engine::Engine(EngineSetup* setup)
		: setup(setup), targetFrameRate(120.0f)
	{
		g_Engine = this;

		timer = new EngineTime();
		window = new Window(setup->width, setup->height, setup->title, this);
		soundManager = new SoundManager();
		commandManager = new CommandManager();

		uint32 createFlag = D3D11_CREATE_DEVICE_BGRA_SUPPORT;
#if _DEBUG
		createFlag |= D3D11_CREATE_DEVICE_DEBUG;
#endif

		D3D_FEATURE_LEVEL featureLevels[] =
		{
			//D3D_FEATURE_LEVEL_11_1,
			D3D_FEATURE_LEVEL_11_0,
		};

		DXGI_SWAP_CHAIN_DESC swapChainDesc = {};
		swapChainDesc.BufferCount = 1;
		swapChainDesc.BufferDesc.Width = setup->width;
		swapChainDesc.BufferDesc.Height = setup->height;
		swapChainDesc.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
		swapChainDesc.Windowed = true;
		swapChainDesc.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
		swapChainDesc.BufferDesc.RefreshRate.Numerator = 60;
		swapChainDesc.BufferDesc.RefreshRate.Denominator = 1;
		swapChainDesc.SampleDesc.Count = 1;
		swapChainDesc.SampleDesc.Quality = 0;
		swapChainDesc.OutputWindow = window->Handle();
		swapChainDesc.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

		ThrowIfFailed(D3D11CreateDeviceAndSwapChain(
			nullptr,
			D3D_DRIVER_TYPE_HARDWARE,
			nullptr,
			createFlag,
			featureLevels,
			_countof(featureLevels),
			D3D11_SDK_VERSION,
			&swapChainDesc,
			&swapChain,
			&device,
			nullptr,
			&deviceContext
		), TEXT("Failed to create device and swap chain."));

		ID3D11Texture2D* backbuffer = nullptr;
		ThrowIfFailed(swapChain->GetBuffer(0u, IID_PPV_ARGS(&backbuffer)), TEXT("Failed to get backbuffer."));
		ThrowIfFailed(
			device->CreateRenderTargetView(backbuffer, nullptr, &renderTargetView),
			TEXT("Failed to create render target view."));

		SafeRelease(backbuffer);

		ID3D11Texture2D* depthStencilResource = NULL;
		D3D11_TEXTURE2D_DESC depthStencilResourceDesc = {};
		depthStencilResourceDesc.Width = setup->width;
		depthStencilResourceDesc.Height = setup->height;
		depthStencilResourceDesc.MipLevels = 1;
		depthStencilResourceDesc.ArraySize = 1;
		depthStencilResourceDesc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
		depthStencilResourceDesc.SampleDesc.Count = 1;
		depthStencilResourceDesc.SampleDesc.Quality = 0;
		depthStencilResourceDesc.Usage = D3D11_USAGE_DEFAULT;
		depthStencilResourceDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
		depthStencilResourceDesc.CPUAccessFlags = 0;
		depthStencilResourceDesc.MiscFlags = 0;

		ThrowIfFailed(
			device->CreateTexture2D(&depthStencilResourceDesc, NULL, &depthStencilResource),
			TEXT("Failed to create depth stencil resource."));

		D3D11_DEPTH_STENCIL_DESC depthStencilDesc = {};

		// Depth test parameters
		depthStencilDesc.DepthEnable = true;
		depthStencilDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
		depthStencilDesc.DepthFunc = D3D11_COMPARISON_LESS;

		// Stencil test parameters
		depthStencilDesc.StencilEnable = true;
		depthStencilDesc.StencilReadMask = 0xFF;
		depthStencilDesc.StencilWriteMask = 0xFF;

		// Stencil operations if pixel is front-facing
		depthStencilDesc.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
		depthStencilDesc.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_INCR;
		depthStencilDesc.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
		depthStencilDesc.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;

		// Stencil operations if pixel is back-facing
		depthStencilDesc.BackFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
		depthStencilDesc.BackFace.StencilDepthFailOp = D3D11_STENCIL_OP_DECR;
		depthStencilDesc.BackFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
		depthStencilDesc.BackFace.StencilFunc = D3D11_COMPARISON_ALWAYS;

		// Create depth stencil state
		ThrowIfFailed(
			device->CreateDepthStencilState(&depthStencilDesc, &depthStencilState),
			TEXT("Failed to create depth stencil state."));

		deviceContext->OMSetDepthStencilState(depthStencilState, 1u);

		D3D11_DEPTH_STENCIL_VIEW_DESC depthStencilViewDesc = {};
		depthStencilViewDesc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
		depthStencilViewDesc.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
		depthStencilViewDesc.Texture2D.MipSlice = 0;

		// Create the depth stencil view
		ThrowIfFailed(
			device->CreateDepthStencilView(depthStencilResource, &depthStencilViewDesc, &depthStencilView),
			TEXT("Failed to create depth stencil view."));

		deviceContext->OMSetRenderTargets(1u, &renderTargetView, depthStencilView);

		D3D11_VIEWPORT viewport = {};
		viewport.TopLeftX = 0.0f;
		viewport.TopLeftY = 0.0f;
		viewport.Width = static_cast<float>(setup->width);
		viewport.Height = static_cast<float>(setup->height);
		viewport.MinDepth = 0.0f;
		viewport.MaxDepth = 1.0f;

		deviceContext->RSSetViewports(1u, &viewport);

		// ������ ���� ���� �ʱ�ȭ.
		D3D11_BLEND_DESC blendDesc = {};
		blendDesc.AlphaToCoverageEnable = false;
		blendDesc.RenderTarget[0] = {};
		blendDesc.RenderTarget[0].BlendEnable = true;
		blendDesc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
		blendDesc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
		blendDesc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
		blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;

		blendDesc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ZERO;
		blendDesc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ONE;
		blendDesc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;

		blendDesc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;

		ThrowIfFailed(
			device->CreateBlendState(&blendDesc, &blendState),
			TEXT("Failed to create blend state."));

		float blendFactor[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
		deviceContext->OMSetBlendState(blendState, blendFactor, 0xff);

		D3D11_RASTERIZER_DESC rasterizerDesc = {};
		rasterizerDesc.CullMode = D3D11_CULL_BACK;
		rasterizerDesc.FillMode = D3D11_FILL_SOLID;

		// �ۼ���: �弼�� 2024.04.15.
		// �����Ͷ����� ������Ʈ ����. (��� �������� ���� ������).
		ThrowIfFailed(device->CreateRasterizerState(&rasterizerDesc, &rasterizerState), TEXT("Failed to create rasterizer state."));
		deviceContext->RSSetState(rasterizerState);

		// 2D ��ġ �ʱ�ȭ.
		InitializeDirect2DDevices();
	}

	Engine::~Engine()
	{
		TextureManager::Release();

		SafeDelete(window);
		SafeDelete(setup);
		SafeDelete(timer);
		SafeDelete(soundManager);
		SafeDelete(commandManager);

		for (Scene* scene : scenes)
		{
			SafeDelete(scene);
		}

		SafeDelete(menuScene);

		SafeRelease(device);
		SafeRelease(deviceContext);
		SafeRelease(swapChain);
		SafeRelease(renderTargetView);
		SafeRelease(depthStencilState);
		SafeRelease(depthStencilView);
		SafeRelease(blendState);
		SafeRelease(rasterizerState);

		SafeRelease(d2dFactory);
		SafeRelease(dwFactory);
		SafeRelease(d2dRenderTarget);
	}

	void Engine::Run()
	{
		timer->Start();
		elapsedTime = 0.0f;
		framesPerSecond = 0;

		TextureManager::Initialize();

		// ī�޶� ����.
		camera = new Camera(Width(), Height(), 90.0f, 0.01f, 1000.0f);
		camera->GetTransform()->SetPosition(0.0f, 0.0f, -5.0f);

		// �޴� �� ���� (�׽�Ʈ).
		menuScene = new MenuScene(this);

		// ���� �� ����.
		//scenes.emplace_back(new StartScene(this));

		// ���� �� ����.
		scenes.emplace_back(new GameScene("../Assets/Stage/Stage1.txt", this, (int)scenes.size()));
		scenes.emplace_back(new GameScene("../Assets/Stage/Stage2.txt", this, (int)scenes.size()));
		scenes.emplace_back(new GameScene("../Assets/Stage/Stage3.txt", this, (int)scenes.size()));

		// ���� �� �ε��� ����.
		currentSceneIndex = 0;

		// ���� ���� ����.
		window->Run(this);
	}

	void Engine::Update()
	{
		// ������ ��Ȱ��ȭ������ Update ó�� ���ϵ��� �Լ� ��ȯ.
		if (isActive == false)
		{
			return;
		}

		// Ÿ�̸� ������Ʈ.
		timer->Update();

		// �Է� ������Ʈ.
		ProcessInput();

		// ������ ��� (������ �������� �����ϵ���).
		if (timer->FrameTime() >= (1.0f / targetFrameRate))
		{
			// FPS ���.
			elapsedTime += timer->frameTime;
			++framesPerSecond;
			if (elapsedTime >= 1.0f)
			{
				std::wstring statString = FormatString(
					TEXT("[%s] [Resolution: %d x %d] [FrameTime: %f second] [FPS: %d]"),
					window->Title().c_str(), setup->width, setup->height, timer->frameTime, framesPerSecond
				);

				SetWindowText(window->Handle(), statString.c_str());

				elapsedTime = 0.0f;
				framesPerSecond = 0;
			}

			// ���� ������Ʈ �̺�Ʈ.
			Update(timer->FrameTime());

			// ���� Draw �̺�Ʈ.
			Draw();

			// ������ ������Ʈ.
			timer->UpdateFrameTime();
		}
	}

	void Engine::OnResize(uint32 width, uint32 height)
	{
		// ��ġ�� ������ �ȵ� ���� ���� ������ �ʱ�ȭ���� ���� �����̱� ������ ��ȯ.
		if (deviceContext == nullptr || device == nullptr || swapChain == nullptr)
		{
			return;
		}

		// ���� ������ ũ�� ����.
		setup->width = width;
		setup->height = height;

		// ���� ���ҽ�����.
		SafeRelease(renderTargetView);
		SafeRelease(depthStencilView);
		SafeRelease(d2dRenderTarget);

		// ���� ü�� ũ�� ����.
		ThrowIfFailed(
			swapChain->ResizeBuffers(1u, width, height, DXGI_FORMAT_R8G8B8A8_UNORM, 0),
			TEXT("Failed to resize swap chain"));

		// ���� Ÿ�� / ���� ���ٽ� �� ���� �� ���ε�.
		ID3D11Texture2D* backbuffer = nullptr;
		ThrowIfFailed(swapChain->GetBuffer(0u, IID_PPV_ARGS(&backbuffer)), TEXT("Failed to get back buffer."));

		ThrowIfFailed(
			device->CreateRenderTargetView(backbuffer, nullptr, &renderTargetView),
			TEXT("Failed to create render target view."));

		SafeRelease(backbuffer);

		ID3D11Texture2D* depthStencilResource = NULL;
		D3D11_TEXTURE2D_DESC depthStencilResourceDesc = {};
		depthStencilResourceDesc.Width = width;
		depthStencilResourceDesc.Height = height;
		depthStencilResourceDesc.MipLevels = 1;
		depthStencilResourceDesc.ArraySize = 1;
		depthStencilResourceDesc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
		depthStencilResourceDesc.SampleDesc.Count = 1;
		depthStencilResourceDesc.SampleDesc.Quality = 0;
		depthStencilResourceDesc.Usage = D3D11_USAGE_DEFAULT;
		depthStencilResourceDesc.BindFlags = D3D11_BIND_DEPTH_STENCIL;
		depthStencilResourceDesc.CPUAccessFlags = 0;
		depthStencilResourceDesc.MiscFlags = 0;

		ThrowIfFailed(
			device->CreateTexture2D(&depthStencilResourceDesc, NULL, &depthStencilResource),
			TEXT("Failed to create depth stencil resource."));

		D3D11_DEPTH_STENCIL_DESC depthStencilDesc = {};

		// Depth test parameters
		depthStencilDesc.DepthEnable = true;
		depthStencilDesc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
		depthStencilDesc.DepthFunc = D3D11_COMPARISON_LESS;

		// Stencil test parameters
		depthStencilDesc.StencilEnable = true;
		depthStencilDesc.StencilReadMask = 0xFF;
		depthStencilDesc.StencilWriteMask = 0xFF;

		// Stencil operations if pixel is front-facing
		depthStencilDesc.FrontFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
		depthStencilDesc.FrontFace.StencilDepthFailOp = D3D11_STENCIL_OP_INCR;
		depthStencilDesc.FrontFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
		depthStencilDesc.FrontFace.StencilFunc = D3D11_COMPARISON_ALWAYS;

		// Stencil operations if pixel is back-facing
		depthStencilDesc.BackFace.StencilFailOp = D3D11_STENCIL_OP_KEEP;
		depthStencilDesc.BackFace.StencilDepthFailOp = D3D11_STENCIL_OP_DECR;
		depthStencilDesc.BackFace.StencilPassOp = D3D11_STENCIL_OP_KEEP;
		depthStencilDesc.BackFace.StencilFunc = D3D11_COMPARISON_ALWAYS;

		// Create depth stencil state
		ThrowIfFailed(
			device->CreateDepthStencilState(&depthStencilDesc, &depthStencilState),
			TEXT("Failed to create depth stencil state."));

		deviceContext->OMSetDepthStencilState(depthStencilState, 1u);

		D3D11_DEPTH_STENCIL_VIEW_DESC depthStencilViewDesc = {};
		depthStencilViewDesc.Format = DXGI_FORMAT_D24_UNORM_S8_UINT;
		depthStencilViewDesc.ViewDimension = D3D11_DSV_DIMENSION_TEXTURE2D;
		depthStencilViewDesc.Texture2D.MipSlice = 0;

		// Create the depth stencil view
		ThrowIfFailed(
			device->CreateDepthStencilView(depthStencilResource, &depthStencilViewDesc, &depthStencilView),
			TEXT("Failed to create depth stencil view."));

		deviceContext->OMSetRenderTargets(1u, &renderTargetView, depthStencilView);

		// ����Ʈ ũ�� ����.
		D3D11_VIEWPORT viewport = {};
		viewport.TopLeftX = 0.0f;
		viewport.TopLeftY = 0.0f;
		viewport.Height = static_cast<float>(height);
		viewport.Width = static_cast<float>(width);
		viewport.MaxDepth = 1.0f;
		viewport.MinDepth = 0.0f;

		deviceContext->RSSetViewports(1u, &viewport);

		// ī�޶� ũ�� ����.
		camera->OnResize(width, height);

		// D2D �ٽ� �ʱ�ȭ.
		InitializeDirect2DDevices();
	}

	void Engine::SetActive(bool active)
	{
		isActive = active;
	}

	void Engine::ChangeScene(int newSceneIndex)
	{
		// ����ó��.
		if (newSceneIndex >= static_cast<int>(scenes.size()))
		{
			return;
		}

		currentSceneIndex = newSceneIndex;
	}

	void Engine::ResumeGame()
	{
		isMenuSceneRendering = false;
	}

	void Engine::QuitGame()
	{
		DestroyWindow(window->Handle());
	}

	void Engine::AddCommand(Command* command, bool execute)
	{
		commandManager->AddCommand(command, execute);
	}

	void Engine::Undo()
	{
		commandManager->Undo();
	}

	void Engine::Redo()
	{
		commandManager->Redo();
	}

	void Engine::InitializeDirect2DDevices()
	{
		if (d2dFactory == nullptr)
		{
			// create Direct2D factory.
			ThrowIfFailed(D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &d2dFactory), TEXT("Failed to create direct2d factory."));
		}

		// Get backbuffer.
		IDXGISurface* backbuffer = nullptr;
		ThrowIfFailed(swapChain->GetBuffer(0u, IID_PPV_ARGS(&backbuffer)), TEXT("Failed to backbuffer."));

		// create Direct2D render target.
		RECT rect;
		GetClientRect(window->Handle(), &rect);
		if (d2dFactory != nullptr)
		{
			float dpi = static_cast<float>(GetDpiForWindow(window->Handle()));
			D2D1_RENDER_TARGET_PROPERTIES properties = D2D1::RenderTargetProperties(
				D2D1_RENDER_TARGET_TYPE_DEFAULT,
				D2D1::PixelFormat(DXGI_FORMAT_UNKNOWN, D2D1_ALPHA_MODE_PREMULTIPLIED),
				dpi,
				dpi
			);

			ThrowIfFailed(
				d2dFactory->CreateDxgiSurfaceRenderTarget(backbuffer, &properties, &d2dRenderTarget),
				TEXT("Failed to create DxgiSurfaceRenderTarget."));

			if (dwFactory == nullptr)
			{
				ThrowIfFailed(
					DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(dwFactory), reinterpret_cast<IUnknown**>(&dwFactory)),
					TEXT("Failed to create DWrite Factory."));
			}

			SafeRelease(backbuffer);
		}
		else
		{
			SafeRelease(backbuffer);
			ThrowIfFailed(E_FAIL, TEXT("d3dFactory is nullptr"));
		}
	}

	void Engine::ProcessInput()
	{
		// �Է� ������ ������ ������Ʈ.
		for (int ix = 0; ix < Input::KeyCount(); ++ix)
		{
			Input::SetKeyState(ix, GetAsyncKeyState(ix) & 0x8000);
		}

		// ESCŰ�� ����.
		if (Input::GetKeyDown(VK_ESCAPE) == true)
		{
			isMenuSceneRendering = !isMenuSceneRendering;
		}

		// ZŰ�� Undo.
		if (Input::GetKey(VK_CONTROL) && Input::GetKeyDown('Z') == true)
		{
			commandManager->Undo();
		}

		// RŰ�� Redo.
		if (Input::GetKey(VK_CONTROL) && Input::GetKeyDown('R') == true)
		{
			commandManager->Redo();
		}
	}

	void Engine::Update(float deltaTime)
	{
		// ī�޶� ������Ʈ.
		camera->Update();

		if (isMenuSceneRendering == true)
		{
			menuScene->Update(deltaTime);
		}
		else
		{
			// ���� �� ������Ʈ.
			scenes[currentSceneIndex]->Update(deltaTime);
		}
	}

	void Engine::Draw()
	{
		// �� �׸��� ����.
		BeginScene();

		// �� �׸���.
		DrawScene();

		// ����� <-> ����Ʈ ���� ��ȯ.
		EndScene();
	}

	void Engine::BeginScene()
	{
		// ���� �޴��� ������ ������ Ȯ���ϰ�, ��Ȳ�� �°� ��� �� ����.
		float* backgroundColor = isMenuSceneRendering == true ? menuScene->backgroundColor : scenes[currentSceneIndex]->backgroundColor;

		//deviceContext->ClearRenderTargetView(renderTargetView, scenes[currentSceneIndex]->backgroundColor);
		deviceContext->ClearRenderTargetView(renderTargetView, backgroundColor);
		deviceContext->ClearDepthStencilView(depthStencilView, D3D11_CLEAR_DEPTH | D3D11_CLEAR_STENCIL, 1.0f, 0u);
	}

	void Engine::DrawScene()
	{
		// ī�޶� ���ε�.
		camera->Bind();
		
		// Begin the 2d scene.
		d2dRenderTarget->BeginDraw();

		// ���� �� �׸���.
		if (isMenuSceneRendering == true)
		{
			menuScene->Draw();
		}
		else
		{
			scenes[currentSceneIndex]->Draw();
		}
	}

	void Engine::EndScene()
	{
		d2dRenderTarget->EndDraw();

		if (isVsync == true)
		{
			swapChain->Present(1u, 0u);
		}
		else
		{
			swapChain->Present(0u, 0u);
		}
	}
}