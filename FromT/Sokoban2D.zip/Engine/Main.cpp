#include "PreCompiledHeader.h"
#include "Engine/Engine.h"

using namespace Ronnie;
Engine* g_Engine = nullptr;

#if _DEBUG

void ReportD3DMemoryLeak()
{
	ID3D11Debug* debug = nullptr;
	ThrowIfFailed(g_Engine->Device()->QueryInterface(IID_PPV_ARGS(&debug)), TEXT("Failed to query debug device"));
	OutputDebugString(L"�޸� ���� üũ ����\n");
	debug->ReportLiveDeviceObjects(D3D11_RLDO_IGNORE_INTERNAL);
	OutputDebugString(L"�޸� ���� üũ ����\n");

	debug->Release();
}
#endif

int main()
{
	new Engine(new EngineSetup(1280u, 800u, TEXT("Sokoban Game")));
	g_Engine->Run();

#if _DEBUG
	ReportD3DMemoryLeak();
#endif

	SafeDelete(g_Engine);

	return 0;
}