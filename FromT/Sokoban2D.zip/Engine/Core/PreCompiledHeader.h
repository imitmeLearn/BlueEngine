#pragma once

#define WIN_LEAN_MAN_MEAN
#define NOMINMAX

#include <Windows.h>
#include <comdef.h>

#include <iostream>
#include <string>
#include <vector>

#include <d3d11.h>
#include <d3dcompiler.h>
#include <dxgi.h>

#include <d2d1.h>
#include <dwrite.h>

#define ShowErrorMessage(message, reason)															\
	wchar_t buffer[256];																			\
	wsprintf(buffer, TEXT("[File: %s]\n[Line: %d]\n[Funcion: %s]\n[Message: %s]\n[Reason: %s]"),	\
			TEXT(__FILE__), __LINE__, TEXT(__FUNCTION__), message, reason);							\
	MessageBox(nullptr, buffer, L"Error", MB_OK);

#define ThrowIfFailed(result, message)							\
	if (FAILED(result))											\
	{															\
		_com_error erorr(result);								\
		ShowErrorMessage(message, erorr.ErrorMessage());		\
		__debugbreak();											\
	}

#define ThrowWithMessage(message)		\
	ThrowIfFailed(E_FAIL, message);

#define GetAsyncKeyDown(key) ((GetAsyncKeyState(key) & 0x8000) ? true : false)
#define GetAsyncKeyUp(key) ((GetAsyncKeyState(key) & 0x8000) ? false : true)
#define EqualsTwoVector2(vector1, vector2) (vector1.x == vector2.x && vector1.y == vector2.y)

#define PrintXMFLOAT3(vector) (std::cout << "(" << vector.x << ", " << vector.y << ", " << vector.z << ")\n")

using uin8 = unsigned char;

using uint32 = unsigned int;
using uint64 = unsigned __int64;

using int32 = int;
using int64 = __int64;

using real32 = float;
using real64 = double;

__forceinline int64 QueryCounter()
{
	LARGE_INTEGER counter;
	QueryPerformanceCounter(&counter);

	return counter.QuadPart;
}

__forceinline int64 QueryFrequency()
{
	LARGE_INTEGER frequency;
	QueryPerformanceFrequency(&frequency);

	return frequency.QuadPart;
}

template<typename Type>
void SafeDelete(Type* pointer)
{
	if (pointer != nullptr)
	{
		delete pointer;
		pointer = nullptr;
	}
}

template<typename Type>
void SafeFree(Type* pointer)
{
	if (pointer != nullptr)
	{
		free(pointer);
		pointer = nullptr;
	}
}

template<typename Type>
void SafeRelease(Type* pointer)
{
	if (pointer != nullptr)
	{
		pointer->Release();
		pointer = nullptr;
	}
}

template<typename... Type>
std::wstring FormatString(const wchar_t* format, Type&&... args)
{
	wchar_t buffer[256];
	std::swprintf(buffer, 256, format, args ...);
	return buffer;
}