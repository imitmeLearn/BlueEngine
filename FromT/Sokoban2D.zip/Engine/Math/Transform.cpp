#include <PreCompiledHeader.h>
#include "Transform.h"

#include "Engine/Engine.h"

namespace Ronnie
{
	Transform::Transform()
		: transformBuffer(nullptr)
	{
		D3D11_BUFFER_DESC bufferDesc = {};
		bufferDesc.ByteWidth = sizeof(XMMATRIX);
		bufferDesc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
		bufferDesc.Usage = D3D11_USAGE_DYNAMIC;
		bufferDesc.CPUAccessFlags = D3D11_CPU_ACCESS_WRITE;

		D3D11_SUBRESOURCE_DATA bufferData = {};
		bufferData.pSysMem = &transformMatrix;

		ThrowIfFailed(
			g_Engine->Device()->CreateBuffer(&bufferDesc, &bufferData, &transformBuffer),
			TEXT("Failed to create transform buffer"));
	}

	Transform::~Transform()
	{
		SafeRelease(transformBuffer);
	}

	void Transform::Update()
	{
		XMMATRIX translationMatrix = XMMatrixTranslation(position.x, position.y, position.z);
		XMMATRIX rotationMatrix = XMMatrixRotationX(rotation.x) * XMMatrixRotationY(rotation.y) * XMMatrixRotationZ(rotation.z);
		XMMATRIX scaleMatrix = XMMatrixScaling(scale.x, scale.y, scale.z);

		transformMatrix = scaleMatrix * rotationMatrix * translationMatrix;
	}

	void Transform::Bind()
	{
		if (parent != nullptr)
		{
			transformMatrix = parent->TransformMatrix() * transformMatrix;
		}

		XMMATRIX bufferMatrix = XMMatrixTranspose(transformMatrix);

		D3D11_MAPPED_SUBRESOURCE mappedResource = {};
		g_Engine->Context()->Map(transformBuffer, 0u, D3D11_MAP_WRITE_DISCARD, 0u, &mappedResource);
		memcpy(mappedResource.pData, &bufferMatrix, sizeof(XMMATRIX));
		g_Engine->Context()->Unmap(transformBuffer, 0u);

		g_Engine->Context()->VSSetConstantBuffers(0u, 1u, &transformBuffer);
	}

	void Transform::SetParent(Transform* parent)
	{
		this->parent = parent;
	}

	void Transform::SetPosition(const XMFLOAT3& position)
	{
		this->position = position;
	}

	void Transform::SetPosition(float x, float y, float z)
	{
		position = XMFLOAT3(x, y, z);
	}

	void Transform::SetRotation(const XMFLOAT3& rotation)
	{
		this->rotation = rotation;
	}

	void Transform::SetRotation(float x, float y, float z)
	{
		rotation = XMFLOAT3(x, y, z);
	}

	void Transform::SetScale(const XMFLOAT3& scale)
	{
		this->scale = scale;
	}

	void Transform::SetScale(float x, float y, float z)
	{
		scale = XMFLOAT3(x, y, z);
	}
}