#pragma once

#include <DirectXMath.h>

namespace Ronnie
{
	using namespace DirectX;

	class Transform
	{
	public:
		Transform();
		~Transform();

		void Update();
		void Bind();

		void SetParent(Transform* parent);
		Transform* Parent() const { return parent; }

		void SetPosition(const XMFLOAT3& position);
		void SetPosition(float x, float y, float z);
		XMFLOAT3 Position() { return position; }

		void SetRotation(const XMFLOAT3& rotation);
		void SetRotation(float x, float y, float z);
		XMFLOAT3 Rotation() { return rotation; }

		void SetScale(const XMFLOAT3& scale);
		void SetScale(float x, float y, float z);
		XMFLOAT3 Scale() { return scale; }

		XMMATRIX TransformMatrix() const { return transformMatrix; }

	private:

		XMMATRIX transformMatrix = XMMATRIX();
		XMFLOAT3 position = XMFLOAT3();
		XMFLOAT3 rotation = XMFLOAT3();
		XMFLOAT3 scale = XMFLOAT3(1.0f, 1.0f, 1.0f);

		Transform* parent = nullptr;

		struct ID3D11Buffer* transformBuffer = nullptr;
	};
}